# Edição pública 1.0.0 — 12/09/2026

Esta edição preserva byte a byte o manuscrito PDF, o protocolo congelado e os 14 arquivos científicos selecionados. A cópia do suplemento substitui dois caminhos pessoais por caminhos relativos e declara essa edição; tabelas e resultados científicos foram preservados. Os executores, instruções e licenças foram preparados para distribuição.

O ZIP inclui código, documentação, manuscrito e resultados de referência. Os oito arquivos brutos da ANP são adquiridos diretamente da fonte, com conferência obrigatória de tamanho e SHA-256. O acervo congelado original continua preservado no ambiente de trabalho. Os resultados de referência ficam separados e não são usados como entradas do recálculo.

Conversas privadas, governança bruta, histórico Git, credenciais, documentos de trabalho, logs e ambientes de execução ficam fora do ZIP. A revisão de privacidade é uma inspeção dos identificadores conhecidos e do conteúdo distribuído, não uma promessa de anonimato de toda fonte pública.

Código próprio: MIT. Texto e figuras próprios: CC BY 4.0. Atribuição: Pesquisa com IA. Fontes e bibliotecas de terceiros são separadas dessas concessões.
