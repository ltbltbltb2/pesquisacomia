# Origem e condições de distribuição

## Materiais próprios

O responsável autorizou, em 12/09/2026, MIT para o código próprio e CC BY 4.0 para texto e figuras próprios, com atribuição pública a Pesquisa com IA. As licenças estão em `LICENSE-CODE.txt` e `LICENSE-CONTENT.md`. O código Python em `04_code/`, `reproduzir.py` e `obter_dados.py` usa MIT. A documentação textual e as contribuições próprias do manuscrito, suplemento, protocolo, tabelas e figuras usam CC BY 4.0, na medida dos direitos aplicáveis. Dados e conteúdos de terceiros não são relicenciados.

## Dados oficiais adquiridos pelo leitor

Fonte: Agência Nacional do Petróleo, Gás Natural e Biocombustíveis (ANP). O ZIP não redistribui os oito arquivos brutos. `FONTES_DADOS.json` informa suas URLs oficiais, datas de aquisição do acervo, tamanhos e hashes. O programa os obtém diretamente da ANP; recusa dados alterados e preserva dados já existentes. Disponibilidade futura das URLs não é garantida.

Catálogo da ANP: https://www.gov.br/anp/pt-br/centrais-de-conteudo/dados-abertos

O portal identifica a série como dados abertos. O rodapé genérico do portal não foi interpretado como licença específica de cada arquivo. A aquisição direta evita atribuir uma licença nova aos arquivos da ANP. Preserve a referência à Agência e à versão dos dados. O estudo não é um produto oficial nem endossado pela ANP.

Os arquivos oficiais baixados contêm identificação, endereço e CNPJ de estabelecimentos. Eles não são declarados anônimos. Não os inclua, nem inclua dados pessoais, credenciais ou caminhos pessoais, em um relato público de reprodução.

## Bibliotecas e literatura

Bibliotecas são instaladas do PyPI com versões e hashes fixados, sob suas próprias licenças. Seus binários não são redistribuídos no ZIP. Obras citadas e dados de terceiros mantêm seus direitos. Não foram incluídos PDFs ou textos integrais da bibliografia de terceiros.

## Limites científicos

Concordância computacional não equivale a validação por pares, certificação institucional ou comprovação de uma tese. Esta edição não declara reprodução por pesquisador humano externo. Consulte o manuscrito e a proveniência para limites e decisões posteriores ao congelamento.
