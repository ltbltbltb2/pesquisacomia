# Protocolo congelado v1 + decisão A5-D02

## Pergunta e alvo

Título proposto: **Variações semanais da gasolina comum nas capitais brasileiras: comparação entre amostras sucessivas e cadastros comuns**.

Qual a magnitude e a frequência da discrepância entre mudança da média dos cadastros pesquisados em semanas sucessivas e mudança líquida média nos cadastros comuns, nas transições elegíveis do acervo retrospectivo ANP das 27 capitais?

Desenho descritivo de auditoria de mensuração. O parâmetro é um funcional finito dos registros disponíveis e elegíveis, não inflação nacional, custo de vida, variação de todos os postos, efeito causal da rotação, poder de mercado ou repasse. A identidade algébrica e o uso de painéis ANP não são novidades reivindicadas.

## Cronologia e dados

Desenvolvimento: semanas ANP com início em 2023, incluindo coletas de 1–6/1/2024 pertencentes à semana 31/12/2023. Confirmação: semanas atuais de 7/1/2024 a 21/12/2025, inclusive, 103 transições (52/51 por ano de referência), cada uma contra a semana imediatamente anterior. A primeira semana-base foi examinada no desenvolvimento; não se alega ausência de toda sobreposição de registros ou independência entre transições. A semana de 28/12/2025 é excluída porque os arquivos adquiridos terminam em 31/12/2025; isso não afirma que a pesquisa ANP tenha sido incompleta.

Antes do congelamento foram examinados resultados somente de desenvolvimento; nos demais registros, estrutura, identidade, cobertura, calendário, unidades e indicadores binários de validade do preço. Não foram calculados médias, variações, discrepâncias ou rankings de preços confirmatórios. Cronologia local e cópias das conversas serão preservadas; não se afirma pré-registro externo.

Usar somente Produto=`GASOLINA`, UF e município da capital, unidade `R$ / litro`, CNPJ textual com 14 dígitos e dígitos verificadores válidos, data válida, preço numérico finito estritamente positivo. Nenhum corte superior de preço, winsorização, interpolação ou junção por semelhança de nomes. Identidade analítica: cadastro CNPJ observado, sem promessa de continuidade física completa.

Construir os conjuntos somente após validar registros. Duplicatas inteiramente idênticas serão removidas uma única vez com contagem registrada. Conflitos de CNPJ×semana (preço, data ou localidade distintos) interrompem a execução para diagnóstico documentado, sem média automática ou escolha da última linha. Erros verificáveis posteriores geram emenda e comparação antes/depois. A união atual tem zero duplicatas, zero mudanças de capital por CNPJ, 3481 CNPJs válidos e zero preços ausentes/não numéricos/não positivos/não finitos no recorte das capitais. Variações textuais de endereço em 129 CNPJs não são excluídas do principal.

Calendário: datas oficiais de domingo a sábado verificadas nas planilhas. Usar a semana de referência para atribuir ano. Preços são observações em datas possivelmente distintas; nenhuma normalização mecânica para sete dias. Preservar contagens por dia e distribuição de intervalos reais.

## Estimandos, elegibilidade e ponderação

Para capital j e semana atual t, S são os cadastros atuais, P os anteriores e I sua interseção. D = média(S,t) − média(P,t−1); W = média em I de [p(i,t)−p(i,t−1)]; C = D−W.

C = A−B, com A=média(S,t)−média(I,t) e B=média(P,t−1)−média(I,t−1). Também A=(1−nI/nS)×[média(S sem I,t)−média(I,t)], e analogamente B. A contribuição é zero quando não há cadastros não comuns. C=0 pode resultar de compensação; não prova ausência de rotação. Os níveis dos não comuns podem incorporar reajustes não observados em pares.

Elegibilidade principal: ambas as semanas observadas, consecutivas, e nI>=5. Todas as 27 capitais constam na cobertura; não exigir sobrevivência de CNPJ até o fim nem descartar cidades por tamanho de discrepância. Os pares inelegíveis não integram o alvo; seus denominadores e motivos são publicados. Viabilidade estrutural alcançada:25/27capitais com >=80%das103transições elegíveis. AC e TO ficam incluídos nas suas transições elegíveis.

Principal: theta=(1/J)×soma_j [média_t elegível de |C_jt|], J=27 se todas têm ao menos um par. Caso inesperado de capital sem par, reportar indisponibilidade e J efetivo; não substituí-la. Secundários: média assinada C; frequências de |C|>=0,01/0,02/0,05; matriz 3×3; discordância de classe; oposição entre classes aumento e queda; discordância conjunta com |C|>=0,02. Cada frequência/matriz é calculada primeiro por capital, depois com igual peso. O peso de cada par é 1/(J×Tj).

P95 principal da distribuição ponderada: menor |C| cujo acumulado dos pesos 1/(J×Tj) alcança 0,95, sem interpolação. P95 agrupado não ponderado com interpolação linear pode ser reportado no suplemento, rotulado. Máximo é descritivo, sem peso. Por capital, apresentar n, cobertura, médias, P95/quantis e frequências.

Classificação após normalizar valores a 12 casas decimais para estabilidade numérica: queda <=−0,01; estabilidade estritamente entre −0,01 e0,01; aumento >=0,01. Oposição significa produto das classes igual a−1, implicando |C|>=0,02. Não é oposição de sinais arbitrariamente pequenos. Discordância de classe não equivale a discrepância material. Margens inclusivas usam a mesma normalização numérica.

Margem prática principal0,02R$/L proposta antes do piloto; contexto0,01/0,05. É convenção editorial substantiva (R$1 em compra hipotética de50L), não padrão oficial, prejuízo ou teste de equivalência. Conclusões serão contínuas e limitadas ao funcional observado. O piloto0,02015165 não fundamenta alegação de ultrapassagem substantiva da margem.

## Sensibilidades e diagnósticos

1. nI>=10.
2. nI/nS>=80% E nI/nP>=80%, equivalente a nI/max(nS,nP)>=80%. A razão pelo mínimo, constante no rascunho v0, foi corrigida por crítica do revisor; pode permanecer somente como indicador de contenção.
3. Comparador J7: comuns com intervalo de coleta exatamente7dias, nJ7>=5. Manter D dos conjuntos completos, definir R7=D−WJ7=C+(W−WJ7). Publicar R7 e a mudança de comparador W−WJ7 separadamente. R7 não recebe rótulo de composição corrigida pelo calendário.
4. Comparador JA: comuns com endereço normalizado igual entre as duas semanas, nJA>=5. Definir RA e mudança W−WJA analogamente. Nenhuma exclusão com base em endereço futuro.
5. Exclusão de Fortaleza inteira, mantendo-a no principal.
6. Anos2024/2025 separados pela semana atual de referência.

Em todas, apresentar número de capitais e pares e o principal recalculado exatamente no mesmo suporte. Listar capitais indisponíveis, sem retirada silenciosa de denominadores. Além disso, mostrar distribuição de intervalos por capital, dias de coleta dos comuns/não comuns, sobreposição nas duas semanas e diferenças de níveis dos não comuns. Associações gráficas são descritivas, sem interpretação causal.

Registrar alterações gerais de abrangência ANP em2024–2025 conforme relatório institucional; examinar contagens efetivas nas capitais. Não assumir regime nacional invariável nem atribuir causalmente diferenças de preço a cortes orçamentários. Não é obrigatória comparação inferencial de regimes.

## Reconciliação com planilhas oficiais

G é o valor numérico armazenado na planilha, com formato de célula registrado separadamente (exemplo verificado2023:0.00). Não se alega reconstrução da publicação em tempo real. q(mu): normalizar mu a12casas, arredondar a0,001 pelo critério de empates para par (ROUND_HALF_EVEN), depois truncar a0,01 para preços positivos. Essa transformação empírica é congelada antes da confirmação e não será ajustada por cidade/período.

Reportar ΔG−W=C+Δ[q(mu)−mu]+Δ[G−q(mu)]. Último termo é resíduo de reconciliação, não seleção institucional identificada. Coincidência de contagem e média não prova identidade dos registros. Médias dos microdados sem q permanecem principal.

Desenvolvimento:1423células reconciliadas em calendário;1411com contagem igual e transformação qcoincidente.12semanas Fortaleza têm1registro adicional nos microdados. Exclusão diagnóstica do mesmo CNPJ reproduz contagem/valor em12/12, incluindo31/12/2023. Não aplicada ao principal; causa institucional desconhecida e não bloqueante para alvo descritivo.

## Incerteza e validação

Nenhum IC, teste de hipótese, equivalência ou decisão inferencial integra a conclusão principal. Resultados por capital, ano, cobertura e sensibilidades mostram os limites descritivos. Reamostragem fica apenas no suplemento: vetores de resultados de transições reais, nunca semanas brutas recombinadas; blocos circulares sincronizados de4semanas,4000réplicas,semente501;sensibilidades2/8. Preservar indisponibilidades. Percentis são faixa algorítmica, sem cobertura nominal. Preservar simulações com subcobertura; não interpretar cobertura simulada como cobertura dos dados reais.

Testes incluem conjuntos invariáveis, rotação com preços constantes, invariância a futuros, ordem/duplicação, rejeição de conflitos, fronteiras de classificação/materialidade, oposição=>materialidade, quantil ponderado, sobreposição assimétrica e identidade do comparador restrito. Recálculo independente parte dos ZIPs brutos com csv/Decimal. Reprodução limpa recalcula confirmação e gráficos, sem reaproveitar saídas derivadas. Comparar resultados determinísticos, preservar divergências e emendas.

Entrega: manuscrito em português com resumo/abstract, introdução, referencial teórico, metodologia, resultados, discussão, conclusão, referências e declaração transparente de produção por IA; PDF/DOCX; dados/código/protocolo/pareceres/suplemento e instruções de reprodução. Não inventar autores, participação humana, validação externa ou submissão editorial.


## Determinação vinculante A5-D02: ordem numérica
Aprovada pelo Pro orquestrador antes da confirmação. Para classes e frequências, D12=N12(D) e W12=N12(W), com Decimal ROUND_HALF_EVEN a 12 casas; C12=D12−W12, representado exatamente em unidades inteiras de 10^-12 R$/L. Materialidade usa |C12|. Comparadores restritos seguem a mesma regra. Médias, theta e quantis continuam com C não arredondado. q permanece inalterada. Testar ±0,0099999999996 em classes opostas. Esta determinação prevalece sobre redações numéricas anteriores. Decisão integral em 00_governance/orchestrator_02_decision.txt.
