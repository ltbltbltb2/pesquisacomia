# Variações semanais da gasolina comum nas capitais brasileiras: comparação entre amostras sucessivas e cadastros comuns

Versão de pesquisa — 6 de setembro de 2026. Autoria humana não atribuída. Dados retrospectivos da ANP; preços nominais em reais por litro.

## Resumo

**Objetivo:** quantificar a discrepância entre a variação das médias de amostras semanais sucessivas de gasolina comum e a variação média nos cadastros CNPJ presentes nas duas semanas. **Métodos:** auditoria descritiva dos microdados da Agência Nacional do Petróleo, Gás Natural e Biocombustíveis (ANP) nas 27 capitais. O desenvolvimento utilizou semanas de referência de 2023; após congelamento local do protocolo, foram analisadas 103 transições com semanas atuais entre 7 de janeiro de 2024 e 21 de dezembro de 2025. A elegibilidade exigiu pelo menos cinco cadastros comuns. A quantidade principal foi a média da discrepância absoluta, primeiro dentro de cada capital e depois com igual peso entre capitais. Foram examinadas classes de variação, cobertura, comparadores restritos e reconciliação com planilhas oficiais. **Resultados:** 2.590 das 2.781 combinações potenciais foram elegíveis (93,1%). A discrepância absoluta média foi R$ 0,01465/L; o percentil 95 ponderado, R$ 0,05569/L. As classes de queda, estabilidade e aumento discordaram em 23,5% das comparações ponderadas; 13,0% combinaram discordância e discrepância de pelo menos R$ 0,02/L. Classes opostas ocorreram em 2,7%. A restrição a coletas separadas por exatamente sete dias alterou o comparador e elevou a discrepância média no mesmo suporte de R$ 0,01347/L para R$ 0,01689/L. **Conclusão:** uma diferença média inferior à referência editorial de dois centavos não implica equivalência entre leituras. O tamanho, a frequência e a concentração das discrepâncias dependem do recorte e do calendário observável. O estudo descreve o acervo elegível e não identifica efeitos causais da rotação, inflação de consumo ou erro da ANP.

Palavras-chave: gasolina; preços de varejo; amostra desbalanceada; comparabilidade temporal; dados abertos.

## Abstract

**Objective:** To quantify discrepancies between changes in successive weekly sample means of regular gasoline prices and mean changes among business identifiers observed in both weeks. **Methods:** We conducted a descriptive measurement audit of ANP microdata for Brazil's 26 state capitals and its federal capital. Development used reference weeks in 2023. Following a local protocol freeze, analysis covered 103 transitions with current weeks from January 7, 2024 to December 21, 2025. Eligibility required at least five common identifiers. The primary quantity averaged absolute discrepancies within each capital and then equally across capitals. **Results:** There were 2,590 eligible capital–transition pairs out of 2,781 potential pairs (93.1%). The mean absolute discrepancy was BRL 0.01465/L and the weighted 95th percentile was BRL 0.05569/L. Decrease, stability and increase classifications disagreed in 23.5% of weighted comparisons; 13.0% combined disagreement with an absolute discrepancy of at least BRL 0.02/L. Opposite classifications occurred in 2.7%. Restricting the comparator to observations exactly seven days apart increased the mean discrepancy on identical support from BRL 0.01347/L to BRL 0.01689/L. **Conclusion:** A mean below a two-cent editorial benchmark does not establish equivalence. Discrepancies vary across capitals and observation calendars. Findings describe the eligible archive and do not identify causal sampling-rotation effects, consumption inflation or ANP errors.

Keywords: gasoline; retail prices; unbalanced samples; temporal comparability; open data.

## 1. Introdução

A comparação entre o preço médio publicado em duas semanas oferece uma descrição acessível do mercado de combustíveis. Contudo, os estabelecimentos observados podem mudar entre as semanas. Nesse caso, a diferença das médias reúne alterações observadas nos cadastros comuns e diferenças relacionadas aos conjuntos efetivamente pesquisados. A pergunta deste artigo é quanto duas leituras definidas com os mesmos microdados divergem: a mudança entre médias das amostras completas e a mudança líquida média dos cadastros comuns às duas semanas.

Nenhuma dessas leituras é, por definição, o preço “verdadeiro” do mercado. A primeira preserva as amostras disponíveis em cada período; a segunda melhora uma dimensão de comparabilidade ao restringir a identidade cadastral, mas descreve somente a interseção observada. Cadastros ausentes não tiveram seus preços contrafactuais observados. Além disso, as visitas ocorrem em datas diferentes: até um cadastro comum pode ter intervalos de coleta distintos de sete dias.

O objetivo é uma auditoria aplicada de mensuração. O artigo não propõe uma nova identidade algébrica, não considera inédito o uso dos microdados ANP e não estima cartel, repasse, inflação familiar ou efeito causal de mudanças amostrais. Sua contribuição consiste em reunir magnitude, distribuição, consequências classificatórias, cobertura, reconciliação e verificações executáveis para um período reservado antes da análise de seus resultados. Essa combinação torna explícito o alcance de afirmações como “o preço subiu” quando o conjunto de observações muda.

## 2. Referencial e delimitação da contribuição

O Consumer Price Index Manual distingue a manutenção da representatividade da amostra da necessidade de comparabilidade temporal, incluindo a atualização de estabelecimentos e produtos (IMF et al., 2020, capítulos 4 e 7). Esse enquadramento sustenta a cautela com a adoção automática de painéis fixos como padrão superior. Aqui, a analogia é restrita ao problema de comparação: o levantamento de combustíveis não é transformado em índice de custo de vida, e não são utilizadas ponderações de consumo.

A literatura brasileira já utiliza painéis de preços ANP para examinar competição e heterogeneidade. Pessoa, Rezende e Assunção (2019) tratam da competição no varejo de combustíveis; nesta pesquisa, foi consultada integralmente a versão de trabalho de dezembro de 2016, com a publicação de 2019 verificada por metadados. Cardoso, Bittencourt e Irwin (2016) discutem heterogeneidade de revendedores e agregação em painel desbalanceado. Esses trabalhos impedem apresentar a simples disponibilidade de registros individuais ou a composição variável como descobertas deste estudo.

Silva et al. (2014) fornecem contexto sobre transmissão de preços e heterogeneidade regional. Para essa referência, a consulta ficou restrita aos metadados, resumo e introdução acessíveis; não se atribuem detalhes ao texto integral não obtido. O presente artigo estima outra quantidade: uma discrepância entre dois funcionais observáveis, sem mecanismo causal de repasse. A busca foi dirigida à pergunta, com três consultas que retornaram 117 registros, incluindo duplicatas entre consultas, e complementação por fontes institucionais. Não constitui revisão sistemática nem demonstra inexistência de estudo equivalente.

## 3. Dados e métodos

### 3.1 Acervo, calendário e cronologia

Foram adquiridos seis arquivos semestrais automotivos da ANP, relativos a 2023–2025, e duas planilhas municipais semanais que cobrem 2022–2023 e 2024–2025. Origem, data de aquisição, tamanho e SHA-256 estão preservados no pacote. O recorte utiliza gasolina comum, identificada como GASOLINA nos microdados e GASOLINA COMUM nas planilhas, unidade R$/litro, municípios das 26 capitais estaduais e Brasília. CNPJ é tratado como texto. Não se unem cadastros por nome comercial.

O calendário oficial verificado vai de domingo a sábado. O desenvolvimento abrangeu semanas iniciadas em 2023, incluindo as coletas de 1–6 de janeiro de 2024 da semana-base de 31 de dezembro de 2023. A análise reservada contém 52 transições atribuídas a 2024 e 51 a 2025, pelas semanas atuais. A semana atual de 28 de dezembro de 2025 foi excluída previamente porque os arquivos adquiridos terminam em 31 de dezembro, antes do encerramento daquela semana. Isso não afirma incompletude da pesquisa ANP.

A especificação foi congelada localmente em 6 de setembro de 2026, às 00:39:40 UTC, após desenvolvimento e revisão do protocolo e antes da execução confirmatória. O termo “confirmatória” designa a aplicação da especificação ao período reservado: não houve pré-registro externo, teste de hipótese ou separação completa dos registros, pois a primeira semana-base foi compartilhada. Antes do congelamento foram examinados, fora do desenvolvimento, estrutura, cobertura, identidade, unidades e indicadores de validade do preço, sem médias, variações ou rankings confirmatórios. Os registros de exposição permanecem disponíveis.

A união dos seis arquivos contém 139.796 observações do recorte das capitais, sem duplicatas CNPJ × semana ou mudança de capital por CNPJ. Os 3.481 identificadores passaram na validação dos dígitos verificadores; 129 apresentam variações textuais de endereço. Não foram identificados preços ausentes, não numéricos, não positivos ou não finitos. Nenhum corte superior, winsorização ou interpolação foi empregado. Continuidade cadastral não certifica continuidade física integral do estabelecimento.

### 3.2 Duas leituras e uma identidade

Para uma capital e duas semanas consecutivas, sejam S os cadastros atuais, P os anteriores e I sua interseção. D representa a diferença entre a média de S na semana atual e a média de P na anterior. W representa a média, entre os integrantes de I, das diferenças individuais de preço. A discrepância é C = D − W, em R$/litro.

A identidade exata pode ser escrita como C = A − B, em que A é a diferença entre a média de S e a dos comuns na semana atual, e B é a diferença equivalente na semana anterior. Cada componente pode ser decomposto na proporção de não comuns multiplicada pela diferença entre o nível médio dos não comuns e o dos comuns. Quando o conjunto de não comuns é vazio, sua contribuição é zero.

C é relativo ao comparador escolhido. Os níveis dos não comuns também podem incorporar reajustes não acompanhados em pares. C igual a zero pode resultar de compensação entre componentes e não demonstra ausência de rotação. W mede a mudança líquida entre duas observações, e não todos os reajustes realizados entre visitas. Ausência na amostra não significa encerramento de empresa.

### 3.3 Elegibilidade, pesos e classificações

A análise principal exige semanas consecutivas observadas e pelo menos cinco cadastros comuns. A grade potencial contém 27 × 103 = 2.781 combinações. Todas as capitais têm sua cobertura publicada; não se exige presença do cadastro até o fim da série. Para cada capital j, calcula-se a média de |C| nas Tj transições elegíveis. A quantidade principal theta é a média dessas 27 médias. Cada par recebe peso 1/(27 × Tj), sem ponderação por população, vendas ou tamanho da amostra de postos.

Os secundários incluem média assinada, frequências de |C| de pelo menos 1, 2 e 5 centavos, percentil 95, matriz de classes e discordância. O percentil 95 é a inversa da distribuição empírica ponderada, sem interpolação. A estabilidade corresponde ao intervalo estrito entre −R$ 0,01/L e +R$ 0,01/L; os limites inclusivos definem queda e aumento. Oposição requer uma leitura em queda e a outra em aumento. Discordância material combina classes diferentes e |C| de pelo menos R$ 0,02/L.

Para indicadores categóricos, D e W são arredondados a 12 casas com empates para par, e a discrepância categórica é sua diferença exata nessa escala. Estatísticas contínuas usam C sem arredondamento intermediário. Essa convenção impede uma incoerência numérica de fronteira entre oposição e materialidade. A referência de dois centavos foi proposta antes do piloto: corresponderia a R$ 1 numa compra hipotética de 50 litros. É referência editorial, não padrão oficial, perda econômica ou margem de equivalência estatística.

### 3.4 Sensibilidades e reconciliação

Foram predefinidos: mínimo de dez comuns; comuns representando pelo menos 80% de ambas as amostras; comparador com intervalo de coleta exatamente igual a sete dias; comparador com endereço normalizado inalterado no par; exclusão de Fortaleza; e anos separados. Cada comparação apresenta o principal no mesmo suporte. Nos comparadores restritos J, mantém-se D e calcula-se R = D − WJ = C + (W − WJ). R não é denominado composição corrigida. Endereço estável significa apenas estabilidade textual normalizada naquele par.

A média municipal reconstruída dos microdados, mu, é comparada ao valor numérico G armazenado nas planilhas oficiais, preservando separadamente o formato da célula. Em desenvolvimento, a transformação empírica q normalizou mu a 12 casas, arredondou a três casas com empates para par e truncou a duas. Ela coincidiu nas 1.411 células com contagem igual. Doze semanas de Fortaleza apresentaram um registro adicional nos microdados; sua exclusão apenas diagnóstica reconciliou as duas medidas nessas semanas. O registro foi mantido no principal, e a causa institucional permaneceu desconhecida.

A mesma q foi aplicada sem ajustes na confirmação. A decomposição ΔG − W = C + Δ[q(mu) − mu] + Δ[G − q(mu)] separa a discrepância dos microdados, a transformação numérica e o resíduo de reconciliação. O último não identifica seleção institucional. Coincidência de contagem e média tampouco prova identidade dos registros. Os documentos ANP foram utilizados para entender a coleta e contextualizar mudanças gerais de abrangência, sem inferir sua incidência específica nas capitais a partir de totais nacionais.

### 3.5 Validação e limites de inferência

A conclusão principal é estritamente descritiva do acervo elegível; não inclui intervalos de confiança, testes ou equivalência. Um exercício suplementar reamostra vetores de transições reais em blocos circulares sincronizados entre capitais, com comprimentos 2, 4 e 8, 4.000 réplicas e semente 501. Não se recompõem semanas brutas para criar pares inexistentes. Simulações de desenvolvimento revelaram subcobertura, preservada no suplemento; as faixas são algorítmicas, sem cobertura nominal alegada. Künsch (1989) fornece apenas referência conceitual para dependência temporal.

Os testes verificaram conjuntos invariáveis, rotação com preços individuais constantes, invariância a informações futuras, ordem de registros, duplicatas, conflitos e fronteiras numéricas. Um recálculo independente leu os ZIPs por csv/Decimal e reproduziu pares, elegibilidade, D/W/C, pesos, média, quantil, matriz e frequências. Não se limitou a reler resultados derivados. A reprodução limpa utiliza ambiente novo e arquivos brutos congelados; relatórios e eventuais emendas integram a entrega. Essa independência é entre implementações, não entre fontes de preços.

## 4. Resultados

### 4.1 Cobertura e magnitude

O recorte de execução contém 93.610 registros de cadastro × semana, incluindo a base compartilhada. Das 2.781 combinações potenciais, 2.590 foram elegíveis (93,13%): 96 tiveram um a quatro comuns, 33 não tiveram comuns e 62 não dispunham de amostra em pelo menos uma semana. A cobertura variou de 72/103 transições em Palmas a 103/103 em oito capitais; Rio Branco teve 81/103. O requisito de viabilidade de pelo menos 20 capitais com 80% de cobertura, registrado na decisão inicial A5-D01 da orquestração, foi satisfeito por 25, sem exclusão de Palmas ou Rio Branco.

A média absoluta foi 1,465 centavo/L, enquanto a média assinada foi −0,0086 centavo/L. A proximidade da segunda de zero reflete compensação de discrepâncias e não substitui a primeira. O percentil 95 ponderado foi 5,569 centavos/L; o máximo, 22,904 centavos/L. As frequências ponderadas de discrepância absoluta de pelo menos 1, 2 e 5 centavos foram, respectivamente, 41,49%, 24,02% e 6,41%.

Tabela 1. Cobertura e discrepância por capital. Valores monetários em centavos/L; frequências em %. Cada capital tem 103 transições potenciais.

| Capital (UF) | Pares | Cobertura % | Média abs(C) | P95 abs(C) | Classes ≠ % |
| --- | --- | --- | --- | --- | --- |
| Rio Branco (AC) | 81 | 78,6 | 0,932 | 2,714 | 30,9 |
| Maceió (AL) | 96 | 93,2 | 1,198 | 4,684 | 15,6 |
| Manaus (AM) | 101 | 98,1 | 0,183 | 1,062 | 4,0 |
| Macapá (AP) | 95 | 92,2 | 1,129 | 7,941 | 15,8 |
| Salvador (BA) | 91 | 88,3 | 1,909 | 5,595 | 5,5 |
| Fortaleza (CE) | 101 | 98,1 | 1,775 | 6,046 | 25,7 |
| Brasília (DF) | 99 | 96,1 | 1,386 | 8,427 | 6,1 |
| Vitória (ES) | 103 | 100,0 | 0,772 | 3,383 | 11,7 |
| Goiânia (GO) | 85 | 82,5 | 2,682 | 11,459 | 30,6 |
| São Luís (MA) | 88 | 85,4 | 2,896 | 9,556 | 46,6 |
| Belo Horizonte (MG) | 100 | 97,1 | 1,993 | 5,400 | 31,0 |
| Campo Grande (MS) | 92 | 89,3 | 1,293 | 3,605 | 39,1 |
| Cuiabá (MT) | 101 | 98,1 | 0,971 | 2,833 | 16,8 |
| Belém (PA) | 91 | 88,3 | 1,337 | 5,529 | 20,9 |
| João Pessoa (PB) | 102 | 99,0 | 0,170 | 0,868 | 2,0 |
| Recife (PE) | 103 | 100,0 | 0,833 | 2,430 | 4,9 |
| Teresina (PI) | 103 | 100,0 | 1,577 | 3,425 | 45,6 |
| Curitiba (PR) | 103 | 100,0 | 1,143 | 3,786 | 29,1 |
| Rio de Janeiro (RJ) | 103 | 100,0 | 2,154 | 5,774 | 57,3 |
| Natal (RN) | 92 | 89,3 | 3,564 | 10,477 | 14,1 |
| Porto Velho (RO) | 103 | 100,0 | 1,918 | 7,000 | 35,0 |
| Boa Vista (RR) | 103 | 100,0 | 0,109 | 0,647 | 1,0 |
| Porto Alegre (RS) | 92 | 89,3 | 1,613 | 4,097 | 34,8 |
| Florianópolis (SC) | 95 | 92,2 | 1,498 | 7,111 | 25,3 |
| Aracaju (SE) | 92 | 89,3 | 0,495 | 1,118 | 2,2 |
| São Paulo (SP) | 103 | 100,0 | 3,004 | 6,719 | 58,3 |
| Palmas (TO) | 72 | 69,9 | 1,023 | 3,730 | 25,0 |

As médias por capital variaram de 0,109 centavo/L em Boa Vista a 3,564 em Natal. São Paulo apresentou 3,004 e São Luís 2,896 centavos/L. Essas estatísticas descrevem suportes locais de tamanhos distintos, explicitados na Tabela 1; não são rankings de qualidade da coleta ou de perdas ao consumidor.

![Média absoluta por capital](figures/figure_1_capitals.png)

Figura 1. Média absoluta de C por capital; linha em dois centavos é referência editorial, não limiar inferencial.

O maior episódio ocorreu em Natal na semana atual de 24 de março de 2024: D = R$ 0,24704/L, W = R$ 0,01800/L e C = R$ 0,22904/L, com cinco comuns entre 16 cadastros atuais e 15 anteriores. Ambas as leituras indicaram aumento. O exemplo mostra que uma discrepância monetária grande pode coexistir com concordância de classe; também evidencia a importância de informar a dimensão do conjunto comum.

### 4.2 Consequências classificatórias e calendário

A frequência ponderada de discordância de classes foi 23,50%, mas somente 2,74% das comparações foram entre aumento e queda. Discordância combinada com discrepância de ao menos dois centavos correspondeu a 13,00%. Logo, não se deve interpretar toda mudança de classe como inversão de direção ou diferença monetária material.

Tabela 2. Matriz de classificação com pesos iguais por capital (% do peso total). Linhas: D; colunas: W.

| D / W | Queda | Estabilidade | Aumento |
| --- | --- | --- | --- |
| Queda | 26,48 | 8,53 | 1,12 |
| Estabilidade | 2,93 | 31,52 | 1,73 |
| Aumento | 1,63 | 7,57 | 18,49 |

Nota: limites inclusivos de ±1 centavo/L; diferenças na soma impressa decorrem do arredondamento.

Entre os pares individuais comuns contabilizados nos diagnósticos, 71,40% (50.013/70.042) das coletas estiveram separadas por exatamente sete dias; os intervalos observados variaram de dois a doze dias. Essa proporção tem denominador de pares de cadastros, diferente dos pesos iguais por capital empregados nos resultados centrais. A mediana agrupada da fração comum em ambas as amostras foi 82,14% nas transições elegíveis. O mapa temporal mostra simultaneamente heterogeneidade das discrepâncias e lacunas de elegibilidade.

![Discrepâncias por capital e semana](figures/figure_2_weekly.png)

Figura 2. Discrepâncias C em centavos/L; cinza indica transição inelegível. A escala comum preserva episódios extremos e pode comprimir diferenças pequenas.

### 4.3 Sensibilidades

Tabela 3. Sensibilidades no mesmo suporte. Valores monetários em centavos/L.

| Recorte | Pares | Capitais | Principal | Alternativo | abs(W−WJ) |
| --- | --- | --- | --- | --- | --- |
| Mínimo 10 comuns | 2295 | 27 | 1,238 | 1,238 | 0,000 |
| Sobreposição ≥80% em ambas | 1356 | 27 | 0,733 | 0,733 | 0,000 |
| Intervalo de sete dias | 1856 | 27 | 1,347 | 1,689 | 0,615 |
| Endereço textual estável | 2590 | 27 | 1,465 | 1,465 | 0,003 |
| Sem Fortaleza | 2489 | 26 | 1,453 | 1,453 | 0,000 |
| 2024 | 1280 | 27 | 1,614 | 1,614 | 0,000 |
| 2025 | 1310 | 27 | 1,323 | 1,323 | 0,000 |

Nota: principal e alternativo são médias absolutas no suporte indicado. Nos recortes que apenas filtram pares, o comparador permanece W; a última coluna é zero por construção. Na exclusão de Fortaleza, CE é a única capital retirada; as demais sensibilidades têm observações das 27 capitais.

Exigir dez comuns reduziu o suporte a 2.295 pares e a média absoluta a 1,238 centavo/L. A alta sobreposição nas duas amostras restringiu o suporte a 1.356 pares e produziu 0,733 centavo/L. São descrições de subconjuntos selecionados pela regra: não estimam quanto uma intervenção que aumentasse a sobreposição reduziria C.

O comparador com sete dias utilizou 1.856 pares. No mesmo suporte, a discrepância principal foi 1,347 centavo/L e o resíduo relativo ao comparador restrito, 1,689. A média absoluta da mudança de comparador foi 0,615 centavo/L. Portanto, restringir o calendário não eliminou mecanicamente a discrepância; alterou o objeto de comparação. A restrição de endereço preservou 2.590 pares e modificou a média de 1,4651 para 1,4654 centavo/L. Isso não certifica identidade física dos estabelecimentos.

Sem Fortaleza, a média foi 1,453 centavo/L em 26 capitais. As análises por ano resultaram em 1,614 em 2024 e 1,323 em 2025, com 1.280 e 1.310 pares elegíveis. Não se atribui essa diferença temporal às mudanças gerais de abrangência institucional.

### 4.4 Reconciliação e consistência computacional

A reconciliação dos níveis, incluindo a semana-base, encontrou 2.772 células com microdados, das quais 2.771 tinham também valor oficial. Em 2.717 células as contagens coincidiram e q reproduziu o valor oficial em todas elas. Houve 54 células com contagens diferentes e 17 divergências numéricas de q entre as células comparáveis: quatro em Fortaleza, seis em Porto Alegre e sete em São Luís. As causas não foram identificadas, e q não foi recalibrada. A célula sem valor oficial corresponde a Porto Alegre, semana de 21 de setembro de 2025, com um registro nos microdados. Todas as exceções estão individualizadas em official_exceptions_complete.csv, e os níveis e a decomposição por transição constam, respectivamente, de official_level_reconciliation.csv e official_change_decomposition.csv, na pasta 05_results/confirmation do pacote.

A decomposição da mudança oficial teve 2.684 transições com dados completos, universo diferente das 2.590 elegíveis do principal. Seu erro numérico máximo foi inferior a 5 × 10⁻¹⁵ R$/L. Essa identidade de cálculo não valida institucionalmente registros ou preços. Na interseção entre elegibilidade principal e disponibilidade de todos os termos oficiais, permaneceram os mesmos 2.590 pares e as 27 capitais. Com pesos iguais por capital e por transição elegível dentro da capital, as médias absolutas foram: 1,4651 centavo/L para C; 0,3126 para a diferença introduzida por q; 0,0109 para o resíduo de reconciliação; e 1,5455 para ΔG − W. As respectivas médias assinadas foram −0,00859, +0,00143, −0,00037 e −0,00752 centavo/L. Médias absolutas de componentes não são aditivas: as identidades se aplicam às diferenças assinadas de cada transição. Os 23,5% de discordância publicados neste artigo referem-se a D e W dos microdados, e não automaticamente a ΔG e W. A execução principal levou aproximadamente 71 segundos, com pico de memória residente de 201,5 MiB no ambiente registrado. O recálculo independente confirmou todas as 17 verificações centrais em 2.719 pares disponíveis, dos quais 2.590 elegíveis. Uma falha inicial no comparador numérico do verificador alternativo foi corrigida e preservada: a correção não alterou o protocolo nem os resultados principais.

## 5. Discussão

A principal implicação é a necessidade de explicitar qual mudança está sendo comunicada. No acervo estudado, a diferença típica em média foi pequena em termos absolutos, mas a distribuição teve episódios maiores e consequências classificatórias frequentes. A média assinada quase nula, isoladamente, ocultaria essa estrutura. Ao mesmo tempo, seria exagerado transformar a discordância de 23,5% em uma afirmação de que as leituras apontam direções opostas em um quarto das semanas: a oposição foi muito menos frequente.

O resultado abaixo da referência de dois centavos não demonstra equivalência. Trata-se de uma média entre capitais e de uma convenção editorial sem teste inferencial; cerca de um quarto das comparações ponderadas alcançou esse limiar e o percentil 95 foi superior a cinco centavos. A heterogeneidade local também importa: Natal teve a maior média absoluta, enquanto São Paulo apresentou frequência de discordância de classe maior. Magnitude monetária e localização em relação aos limites das classes são propriedades diferentes.

O calendário de coleta merece atenção própria. A comparação com exatamente sete dias alterou a leitura dos cadastros comuns e aumentou a discrepância no mesmo suporte. Esse achado impede tratar o pareamento por identidade como sincronização completa das observações. A distinção entre C e R evita atribuir ao componente de composição uma modificação que decorre da redefinição do comparador.

O relatório preliminar de análise de impacto regulatório da ANP em 2025 descreve configurações de contingenciamento e redução do levantamento, e apresenta a recomposição a partir de dezembro como previsão. O documento contextualiza possíveis mudanças de cobertura, mas não prova a configuração efetivamente realizada em cada capital ou seu efeito sobre preços. Os denominadores observados, as lacunas e as análises por ano devem acompanhar essa contextualização. A melhora ou piora de uma estatística entre anos não identifica causa institucional.

Há limites importantes. O alvo exclui transições sem pelo menos cinco comuns e não representa automaticamente os pares ausentes. A ponderação igual por capital favorece uma síntese entre localidades, sem representar consumo nacional. Cadastros comuns podem ser seletivos, e estabilidade de endereço é um diagnóstico textual limitado. Não há preços dos ausentes que permitam identificar reajustes contrafactuais. O acervo é retrospectivo, sem versões semanais históricas que reproduzam a informação disponível em tempo real. A reconciliação confronta dois produtos da mesma fonte e não é auditoria independente de preços nas bombas. Finalmente, a contribuição é uma auditoria delimitada; sua utilidade editorial depende de tornar esses limites tão visíveis quanto os números centrais.

## 6. Conclusão

Nas 2.590 transições elegíveis das 27 capitais, a discrepância absoluta média entre mudanças das amostras completas e mudanças nos cadastros comuns foi R$ 0,01465/L. O percentil 95 foi R$ 0,05569/L e as classes discordaram em 23,5% das comparações ponderadas, com oposição entre aumento e queda em 2,7%. Os resultados sustentam a apresentação conjunta de magnitude, classe, cobertura e definição do comparador. Não sustentam equivalência universal entre leituras, efeito causal da rotação ou erro da ANP. Para usos descritivos semelhantes, publicar o conjunto comum, o calendário e os denominadores permite avaliar com maior precisão o alcance da mudança comunicada.

## Disponibilidade, produção e transparência

O pacote contém protocolo congelado, proveniência dos dados, códigos, tabelas completas, diagnósticos, relatórios de testes, instruções de reprodução e registros de revisão. Documentos bibliográficos de terceiros consultados não integram o pacote redistribuível; seus endereços e níveis de acesso estão registrados. A entrega não corresponde a submissão a periódico.

Este manuscrito foi produzido com assistência de IA. O Codex executou aquisição, análise, documentação e composição; uma conversa Pro atuou na orquestração científica, e outra conversa Pro temporária, iniciada sem o contexto de elaboração, revisou o protocolo e o manuscrito. A mesma conversa de revisão foi mantida nas rodadas. Os pareceres são revisões por IA e não avaliação independente por pesquisadores humanos. As decisões e correções ficam documentadas; não se atribuem autores, afiliações, financiamento ou aprovação humana inexistentes.

## Referências

ANP — Agência Nacional do Petróleo, Gás Natural e Biocombustíveis. Série histórica de preços de combustíveis e dados abertos do levantamento de preços. Arquivos automotivos semestrais de 2023–2025 e planilhas municipais semanais. Acervo adquirido em setembro de 2026. https://www.gov.br/anp/pt-br/centrais-de-conteudo/dados-abertos/serie-historica-de-precos-de-combustiveis

ANP. Metodologia de coleta do Levantamento de Preços de Combustíveis. 2022. https://www.gov.br/anp/pt-br/assuntos/precos-e-defesa-da-concorrencia/precos/precos-revenda-e-de-distribuicao-combustiveis/arquivos-metodologia/metodologia-coleta.pdf

ANP. Relatório preliminar de análise de impacto regulatório. Relatório 6, processo SEI 48610.212650/2025-19. Consulta prévia 03/2025. https://www.gov.br/anp/pt-br/assuntos/consultas-e-audiencias-publicas/consulta-previa/2025/cp-03-2025/rpair.pdf

CARDOSO, L. C. B.; BITTENCOURT, M. V. L.; IRWIN, E. G. Price asymmetry and retailers heterogeneity in Brazilian gas stations. ERSA Congress, 2016. Versão de congresso consultada integralmente. https://www.econstor.eu/bitstream/10419/174682/1/Paper0796_MauricoBittencourt.pdf

INTERNATIONAL MONETARY FUND et al. Consumer Price Index Manual: Concepts and Methods. Washington, DC: IMF, 2020. Capítulos 4 e 7. https://www.imf.org/-/media/Files/Data/CPI/cpi-manual-concepts-and-methods.ashx

KÜNSCH, H. R. The Jackknife and the Bootstrap for General Stationary Observations. The Annals of Statistics, 17(3), 1217–1241, 1989. https://doi.org/10.1214/aos/1176347265

PESSOA, J. P.; REZENDE, L.; ASSUNÇÃO, J. Flex cars and competition in fuel retail markets. International Journal of Industrial Organization, 63, 145–184, 2019. https://doi.org/10.1016/j.ijindorg.2018.07.005 . Publicação verificada por metadados; versão integral consultada: working paper, dezembro de 2016, https://www.climatepolicyinitiative.org/wp-content/uploads/2017/08/WorkingPaper-Flex_Cars_and_Competition.pdf

SILVA, A. S.; VASCONCELOS, C. R. F.; VASCONCELOS, S. P.; MATTOS, R. S. Symmetric transmission of prices in the retail gasoline market in Brazil. Energy Economics, 43, 11–21, 2014. https://doi.org/10.1016/j.eneco.2014.02.002 . Consulta de metadados, resumo e introdução; texto integral não obtido.
