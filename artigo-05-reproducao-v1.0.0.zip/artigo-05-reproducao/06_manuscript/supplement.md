# Suplemento de resultados e validação

As faixas de reamostragem abaixo são apenas algorítmicas. Não são ICs populacionais nem justificam equivalência. Tabelas CSV são canônicas para precisão integral.

## summary.json

```json
{
  "n_pairs": 2590,
  "n_capitals": 27,
  "mean_abs_C_equal_capitals": 0.014651044032826048,
  "mean_C_equal_capitals": -8.585437973483458e-05,
  "class_disagreement_equal_capitals": 0.2350320302275675,
  "opposite_direction_equal_capitals": 0.02742105858553523,
  "p95_abs_C_pooled": 0.05546914517484465,
  "max_abs_C": 0.229041666666666,
  "p95_abs_C_equal_capitals": 0.055693278244258376,
  "material_disagreement_equal_capitals": 0.1299727198214961,
  "abs_at_least_1c_equal_capitals": 0.41492724459006947,
  "abs_at_least_2c_equal_capitals": 0.24016066557447877,
  "abs_at_least_5c_equal_capitals": 0.06405177496224697,
  "class_matrix_equal_capitals": [
    {
      "class_D": -1,
      "class_W": -1,
      "weight": 0.2648442211811589
    },
    {
      "class_D": -1,
      "class_W": 0,
      "weight": 0.08531314342742805
    },
    {
      "class_D": -1,
      "class_W": 1,
      "weight": 0.011152285578465511
    },
    {
      "class_D": 0,
      "class_W": -1,
      "weight": 0.02931577327478478
    },
    {
      "class_D": 0,
      "class_W": 0,
      "weight": 0.3152004439801767
    },
    {
      "class_D": 0,
      "class_W": 1,
      "weight": 0.017311596781292155
    },
    {
      "class_D": 1,
      "class_W": -1,
      "weight": 0.016268773007069724
    },
    {
      "class_D": 1,
      "class_W": 0,
      "weight": 0.0756704581585273
    },
    {
      "class_D": 1,
      "class_W": 1,
      "weight": 0.18492330461109682
    }
  ],
  "protocol_sha256": "43e312bb4f6c67f3689c04bc9ac3bd30678dffddb29bd6f613862452fccc1f34",
  "raw_station_week_records": 93610,
  "expected_pairs": 2781,
  "identity_max_error": 3.094746681142624e-15,
  "expanded_identity_max_error": 4.410100756802038e-15,
  "official_decomposition_max_error": 4.440892098500626e-15
}
```

## diagnostics_summary.json

```json
{
  "reconciliation_rows": 2772,
  "both_available": 2771,
  "missing_microdata": 0,
  "missing_official": 1,
  "same_count": 2717,
  "same_count_q_match": 2717,
  "different_count": 54,
  "q_mismatch": 17,
  "mismatch_cities": {
    "FORTALEZA": 4,
    "PORTO ALEGRE": 6,
    "SAO LUIS": 7
  },
  "coverage_reasons": {
    "eligible": 2590,
    "one_to_four_common": 96,
    "missing_sample_in_pair": 62,
    "no_common": 33
  },
  "eligible_coverage": 0.9313196691837469,
  "gap_distribution": {
    "2": 10,
    "3": 91,
    "4": 448,
    "5": 2724,
    "6": 7049,
    "7": 50013,
    "8": 6748,
    "9": 2583,
    "10": 332,
    "11": 37,
    "12": 7
  },
  "lowest_theta_capitals": [
    {
      "uf": "RR",
      "mean_abs_C": 0.0010882645814114,
      "n": 103
    },
    {
      "uf": "PB",
      "mean_abs_C": 0.0016997301959628,
      "n": 102
    },
    {
      "uf": "AM",
      "mean_abs_C": 0.0018262050336736,
      "n": 101
    }
  ],
  "highest_theta_capitals": [
    {
      "uf": "MA",
      "mean_abs_C": 0.028963164854363,
      "n": 88
    },
    {
      "uf": "SP",
      "mean_abs_C": 0.0300410543420557,
      "n": 103
    },
    {
      "uf": "RN",
      "mean_abs_C": 0.0356432603862651,
      "n": 92
    }
  ],
  "largest_pairs": [
    {
      "uf": "RN",
      "week": "2024-03-24",
      "D": 0.2470416666666661,
      "W": 0.0180000000000001,
      "C": 0.229041666666666,
      "n_common": 5,
      "n_now": 16,
      "n_old": 15
    },
    {
      "uf": "RN",
      "week": "2024-07-07",
      "D": 0.3040277777777769,
      "W": 0.53,
      "C": -0.2259722222222231,
      "n_common": 5,
      "n_now": 16,
      "n_old": 18
    },
    {
      "uf": "BA",
      "week": "2025-02-02",
      "D": 0.287857142857141,
      "W": 0.4763636363636362,
      "C": -0.1885064935064951,
      "n_common": 11,
      "n_now": 22,
      "n_old": 28
    },
    {
      "uf": "SE",
      "week": "2024-04-28",
      "D": 0.1139583333333336,
      "W": 0.2999999999999998,
      "C": -0.1860416666666662,
      "n_common": 6,
      "n_now": 6,
      "n_old": 16
    },
    {
      "uf": "DF",
      "week": "2024-05-19",
      "D": -0.1847224489795929,
      "W": -0.005,
      "C": -0.1797224489795928,
      "n_common": 24,
      "n_now": 49,
      "n_old": 50
    }
  ],
  "official_complete_transitions": 2684,
  "same_day_common_share": 0.7140430027697667,
  "median_overlap_both_eligible": 0.8214285714285714
}
```

## supplemental_block_resampling.json

```json
[
  {
    "block": 2,
    "repetitions": 4000,
    "valid_repetitions": 4000,
    "seed": 501,
    "lower": 0.013640992544809044,
    "upper": 0.015768363490514508,
    "interpretation": "Temporal block resampling sensitivity; not design-based population confidence"
  },
  {
    "block": 4,
    "repetitions": 4000,
    "valid_repetitions": 4000,
    "seed": 501,
    "lower": 0.013542461405218337,
    "upper": 0.015892702185433108,
    "interpretation": "Temporal block resampling sensitivity; not design-based population confidence"
  },
  {
    "block": 8,
    "repetitions": 4000,
    "valid_repetitions": 4000,
    "seed": 501,
    "lower": 0.013402520296783666,
    "upper": 0.01599365292251171,
    "interpretation": "Temporal block resampling sensitivity; not design-based population confidence"
  }
]
```

## resources.json

```json
{
  "started_at": "2026-09-06T00:39:41.311128+00:00",
  "finished_at": "2026-09-06T00:40:52.543471+00:00",
  "seconds": 71.2323601829994,
  "peak_rss_MiB": 201.5
}
```

## core_tests.json

```json
{
  "checks": {
    "fixed_set_composition_zero": true,
    "restricted_comparator_can_differ_without_rotation": true,
    "constant_individual_prices_rotation": true,
    "classification_boundaries": true,
    "material_boundary": true,
    "opposite_classes_imply_material_discrepancy": true,
    "A5_D02_opposition_rounding": true,
    "overlap_must_cover_both_samples": true,
    "weighted_quantile_inverse_ecdf": true,
    "empirical_q_ties": true,
    "future_prices_do_not_change_past": true,
    "future_presence_does_not_change_past": true,
    "row_order_invariant": true,
    "shuffled_numerical_invariant": true,
    "exact_duplicate_invariant": true,
    "conflicting_duplicate_rejected": true,
    "independent_same_pair_count": true,
    "independent_D": true,
    "independent_W": true,
    "independent_C": true,
    "independent_n_common": true
  },
  "all_pass": true,
  "seconds": 48.534316589997616,
  "independent_pairs": 1390,
  "independent_starts_from": "original ZIP CSV with stdlib csv and Decimal; no derived price input"
}
```

## independent_confirmation_checks.json

```json
{
  "checks": {
    "pair_keys": true,
    "D": true,
    "W": true,
    "C": true,
    "n_common": true,
    "eligibility_count": true,
    "capitals": true,
    "matrix": true,
    "mean_abs_C_equal_capitals": true,
    "class_disagreement_equal_capitals": true,
    "abs_at_least_2c_equal_capitals": true,
    "p95_abs_C_equal_capitals": true,
    "abs_at_least_1c_equal_capitals": true,
    "abs_at_least_5c_equal_capitals": true,
    "opposite_direction_equal_capitals": true,
    "material_disagreement_equal_capitals": true,
    "mean_C_equal_capitals": true
  },
  "all_pass": true,
  "independent_summary": {
    "mean_abs_C_equal_capitals": 0.014651044032825987,
    "class_disagreement_equal_capitals": 0.23503203022756752,
    "abs_at_least_2c_equal_capitals": 0.24016066557447877,
    "p95_abs_C_equal_capitals": 0.055693278244257856,
    "abs_at_least_1c_equal_capitals": 0.41492724459006947,
    "abs_at_least_5c_equal_capitals": 0.06405177496224698,
    "opposite_direction_equal_capitals": 0.027421058585535233,
    "material_disagreement_equal_capitals": 0.1299727198214961,
    "mean_C_equal_capitals": -8.585437973484237e-05
  },
  "seconds": 10.92833071599307,
  "raw_pairs": 2719,
  "source": "stdlib csv/Decimal over raw archives; independent math.fsum/Fraction aggregations"
}
```

## block_simulation.json

```json
{
  "seed": 505,
  "simulations": 200,
  "replicates": 499,
  "n_weeks": 103,
  "known_mean": 0.02,
  "results": [
    {
      "phi": 0.0,
      "block": 2,
      "empirical_coverage": 0.915,
      "mean_width": 0.002292666305986769
    },
    {
      "phi": 0.0,
      "block": 4,
      "empirical_coverage": 0.915,
      "mean_width": 0.0022631118067691805
    },
    {
      "phi": 0.0,
      "block": 8,
      "empirical_coverage": 0.905,
      "mean_width": 0.0021960189680652687
    },
    {
      "phi": 0.3,
      "block": 2,
      "empirical_coverage": 0.895,
      "mean_width": 0.0025946938646665757
    },
    {
      "phi": 0.3,
      "block": 4,
      "empirical_coverage": 0.905,
      "mean_width": 0.002779198525779809
    },
    {
      "phi": 0.3,
      "block": 8,
      "empirical_coverage": 0.905,
      "mean_width": 0.002821557994035319
    },
    {
      "phi": 0.7,
      "block": 2,
      "empirical_coverage": 0.725,
      "mean_width": 0.002868746046618004
    },
    {
      "phi": 0.7,
      "block": 4,
      "empirical_coverage": 0.81,
      "mean_width": 0.003527145411186988
    },
    {
      "phi": 0.7,
      "block": 8,
      "empirical_coverage": 0.85,
      "mean_width": 0.004036869549880374
    }
  ],
  "limits": "Stationary lognormal AR(1) common-week toy process. Does not calibrate real ANP coverage, missingness, heterogeneity or structural breaks."
}
```

## cnpj_and_calendar_checks.json

```json
{
  "unique_cnpj": 3481,
  "invalid_check_digits": 0,
  "date_outside_week": 0,
  "same_id_multiple_city": 0
}
```

## price_validity_flags_only.json

```json
[
  {
    "file": "ca-2023-01.zip",
    "capital_gasoline_rows": 23058,
    "missing_or_non_numeric": 0,
    "nonpositive_or_nonfinite": 0
  },
  {
    "file": "ca-2023-02.zip",
    "capital_gasoline_rows": 22335,
    "missing_or_non_numeric": 0,
    "nonpositive_or_nonfinite": 0
  },
  {
    "file": "ca-2024-01.zip",
    "capital_gasoline_rows": 22084,
    "missing_or_non_numeric": 0,
    "nonpositive_or_nonfinite": 0
  },
  {
    "file": "ca-2024-02.zip",
    "capital_gasoline_rows": 24638,
    "missing_or_non_numeric": 0,
    "nonpositive_or_nonfinite": 0
  },
  {
    "file": "ca-2025-01.zip",
    "capital_gasoline_rows": 23767,
    "missing_or_non_numeric": 0,
    "nonpositive_or_nonfinite": 0
  },
  {
    "file": "ca-2025-02.zip",
    "capital_gasoline_rows": 23914,
    "missing_or_non_numeric": 0,
    "nonpositive_or_nonfinite": 0
  }
]
```

## Reprodução limpa

```json
{
  "created_at": "2026-09-06T00:44:01.246179+00:00",
  "seconds": 101.99205366900424,
  "clean_target": "09_reproduction/clean_run",
  "derived_inputs_reused": false,
  "fresh_venv": true,
  "raw_sources": "byte-preserved files with SHA-256 verified by execution; no new network acquisition",
  "checks": {
    "05_results/confirmation/contrasts_all_available.csv": true,
    "05_results/confirmation/eligible_contrasts.csv": true,
    "05_results/confirmation/by_capital.csv": true,
    "05_results/confirmation/sensitivity_summary.csv": true,
    "05_results/confirmation/sensitivity_by_capital.csv": true,
    "05_results/confirmation/coverage_all_expected.csv": true,
    "05_results/confirmation/collection_gap_counts.csv": true,
    "05_results/confirmation/collection_weekday_counts.csv": true,
    "05_results/confirmation/official_level_reconciliation.csv": true,
    "05_results/confirmation/official_change_decomposition.csv": true,
    "05_results/confirmation/supplemental_block_resampling.json": true,
    "05_results/confirmation/summary.json": true,
    "05_results/confirmation/diagnostics_summary.json": true,
    "05_results/confirmation/reconciliation_exceptions.csv": true,
    "06_manuscript/figures/figure_1_capitals.png": true,
    "06_manuscript/figures/figure_2_weekly.png": true,
    "06_manuscript/figures/figure_3_distribution.png": true,
    "06_manuscript/figures/figure_4_coverage.png": true
  },
  "independent_all_pass": true,
  "all_pass": true
}
```

## Emendas de implementação

# Emendas de implementação após congelamento

2026-09-06T00:41:56.983957+00:00 — O primeiro recálculo independente concordou em todos os pares, D/W/C, elegibilidade, theta, quantis e materialidade, mas divergiu nas classes. Diagnóstico: o verificador alternativo comparava Decimal arredondado a limiar float .01, cuja representação é ligeiramente superior a 0,01. Corrigidos somente os limiares do verificador para Decimal exato; análise principal e protocolo inalterados. Falha inicial preservada em independent_confirmation_checks_initial_failure.json; repetir e comparar integralmente.

Código de figuras e relatórios descritivos foi acrescentado após resultados, conforme entrega prevista; não altera estimandos nem elegibilidade.


## Diagnóstico dos comuns e não comuns

Medianas abaixo são agrupadas dentro da capital; diferenças de níveis são nominais, não causais. Quando não há não comuns, a diferença auxiliar é zero por convenção algébrica, e não uma média observada desse grupo.

| UF | Mediana I/max(S,P) | Gap atual não comuns (R$/L) | Gap anterior (R$/L) |
| --- | --- | --- | --- |
| AC | 0,786 | 0,0000 | 0,0000 |
| AL | 0,605 | -0,0039 | -0,0039 |
| AM | 0,875 | 0,0006 | 0,0005 |
| AP | 1,000 | 0,0000 | 0,0000 |
| BA | 0,733 | -0,0175 | -0,0107 |
| CE | 0,609 | 0,0007 | -0,0009 |
| DF | 0,920 | 0,0046 | 0,0046 |
| ES | 0,917 | 0,0000 | 0,0000 |
| GO | 0,628 | -0,0109 | -0,0125 |
| MA | 0,512 | 0,0241 | 0,0199 |
| MG | 0,850 | 0,0004 | 0,0000 |
| MS | 0,826 | 0,0007 | 0,0115 |
| MT | 0,842 | -0,0019 | -0,0030 |
| PA | 0,947 | 0,0000 | 0,0000 |
| PB | 0,947 | 0,0000 | 0,0000 |
| PE | 0,778 | -0,0001 | 0,0026 |
| PI | 0,586 | -0,0064 | -0,0044 |
| PR | 0,562 | -0,0066 | -0,0102 |
| RJ | 0,819 | -0,0904 | -0,0664 |
| RN | 0,575 | -0,0024 | 0,0000 |
| RO | 0,789 | 0,0061 | 0,0100 |
| RR | 1,000 | 0,0000 | 0,0000 |
| RS | 0,789 | 0,0245 | 0,0235 |
| SC | 0,882 | 0,0000 | 0,0000 |
| SE | 1,000 | 0,0000 | 0,0000 |
| SP | 0,837 | -0,0046 | -0,0056 |
| TO | 0,857 | 0,0000 | 0,0000 |

## Contagens efetivas por mês de referência

Inclui a semana-base de dezembro de 2023. Meses têm números distintos de semanas; não comparar totais mensais como se fossem médias semanais.

| Mês | Registros | CNPJs distintos |
| --- | --- | --- |
| 2023-12 | 849 | 849 |
| 2024-01 | 3380 | 1430 |
| 2024-02 | 3407 | 1378 |
| 2024-03 | 4190 | 1389 |
| 2024-04 | 3453 | 1456 |
| 2024-05 | 3327 | 1401 |
| 2024-06 | 4388 | 1483 |
| 2024-07 | 3674 | 1226 |
| 2024-08 | 3685 | 1298 |
| 2024-09 | 4683 | 1361 |
| 2024-10 | 3659 | 1386 |
| 2024-11 | 3649 | 1341 |
| 2024-12 | 4546 | 1368 |
| 2025-01 | 3689 | 1318 |
| 2025-02 | 3662 | 1312 |
| 2025-03 | 4516 | 1428 |
| 2025-04 | 3621 | 1333 |
| 2025-05 | 3732 | 1355 |
| 2025-06 | 4673 | 1298 |
| 2025-07 | 3620 | 1254 |
| 2025-08 | 4624 | 1282 |
| 2025-09 | 3588 | 1281 |
| 2025-10 | 3747 | 1386 |
| 2025-11 | 4530 | 1317 |
| 2025-12 | 2718 | 1203 |

## Complemento da revisão 2 — reconciliação verificável

Os níveis e a decomposição por transição estão, respectivamente, em official_level_reconciliation.csv e official_change_decomposition.csv na pasta 05_results/confirmation. O resumo abaixo usa a interseção da elegibilidade principal com todos os termos oficiais disponíveis:2590pares,27capitais; igual peso por capital e por transição dentro da capital. Médias absolutas de componentes não são aditivas. q não foi recalibrada.

```json
{
  "scope": "Intersection of principal eligibility and all official decomposition terms available; weights equal per capital and within-capital available transitions",
  "n_pairs": 2590,
  "n_capitals": 27,
  "unavailable_capitals": [],
  "identity_max_error": 4.400126096815171e-15,
  "components": [
    {
      "component": "C",
      "n_pairs": 2590,
      "n_capitals": 27,
      "mean_equal_capitals": -8.58543797348332e-05,
      "mean_abs_equal_capitals": 0.014651044032826008,
      "max_abs": 0.229041666666666
    },
    {
      "component": "delta_precision",
      "n_pairs": 2590,
      "n_capitals": 27,
      "mean_equal_capitals": 1.4349575159009691e-05,
      "mean_abs_equal_capitals": 0.003126318721865718,
      "max_abs": 0.0099871794871804
    },
    {
      "component": "delta_reconciliation",
      "n_pairs": 2590,
      "n_capitals": 27,
      "mean_equal_capitals": -3.667033370003479e-06,
      "mean_abs_equal_capitals": 0.0001087318876815222,
      "max_abs": 0.0200000000000004
    },
    {
      "component": "official_change_minus_W",
      "n_pairs": 2590,
      "n_capitals": 27,
      "mean_equal_capitals": -7.517183794583501e-05,
      "mean_abs_equal_capitals": 0.015455236764023019,
      "max_abs": 0.2319999999999998
    }
  ]
}
```

### Relação completa de exceções

Valores em R$/L; uma linha por capital e semana. Campo vazio significa ausente. Divergências de contagem permanecem mesmo quando q e G coincidem.

| UF | Semana | n bruto | n oficial | mu | q | G | G−q |
| --- | --- | --- | --- | --- | --- | --- | --- |
| CE | 2023-12-31 | 47 | 46.0 | 5.971489361702128 | 5.97 | 5.97 | 0.0 |
| CE | 2024-01-14 | 45 | 44.0 | 5.969555555555555 | 5.97 | 5.96 | -0.0099999999999997 |
| CE | 2024-01-28 | 46 | 45.0 | 5.95695652173913 | 5.95 | 5.95 | 0.0 |
| CE | 2024-02-04 | 47 | 46.0 | 5.966382978723405 | 5.96 | 5.96 | 0.0 |
| CE | 2024-02-11 | 47 | 46.0 | 6.163829787234042 | 6.16 | 6.16 | 0.0 |
| CE | 2024-02-18 | 47 | 46.0 | 6.149574468085107 | 6.15 | 6.14 | -0.0100000000000006 |
| CE | 2024-02-25 | 46 | 45.0 | 6.119782608695652 | 6.12 | 6.11 | -0.0099999999999997 |
| CE | 2024-03-03 | 46 | 45.0 | 6.045434782608696 | 6.04 | 6.04 | 0.0 |
| CE | 2024-03-17 | 48 | 47.0 | 5.867083333333333 | 5.86 | 5.86 | 0.0 |
| CE | 2024-04-07 | 46 | 45.0 | 5.649347826086957 | 5.64 | 5.65 | 0.0100000000000006 |
| RS | 2024-06-30 | 32 | 33.0 | 5.8290625 | 5.82 | 5.83 | 0.0099999999999997 |
| RS | 2024-07-07 | 33 | 34.0 | 5.896060606060606 | 5.89 | 5.91 | 0.0200000000000004 |
| RS | 2024-07-14 | 33 | 34.0 | 6.222727272727273 | 6.22 | 6.22 | 0.0 |
| RS | 2024-07-28 | 34 | 35.0 | 6.120294117647059 | 6.12 | 6.12 | 0.0 |
| RS | 2024-08-04 | 34 | 35.0 | 6.124411764705882 | 6.12 | 6.12 | 0.0 |
| RS | 2024-08-11 | 34 | 35.0 | 6.116470588235295 | 6.11 | 6.11 | 0.0 |
| RS | 2024-08-18 | 35 | 36.0 | 6.056571428571428 | 6.05 | 6.05 | 0.0 |
| RS | 2024-09-01 | 33 | 34.0 | 5.998484848484848 | 5.99 | 5.99 | 0.0 |
| RS | 2024-09-08 | 34 | 35.0 | 6.015294117647059 | 6.01 | 6.01 | 0.0 |
| RS | 2024-09-22 | 34 | 35.0 | 5.994117647058824 | 5.99 | 5.99 | 0.0 |
| RS | 2024-10-20 | 35 | 36.0 | 5.944285714285715 | 5.94 | 5.94 | 0.0 |
| RS | 2025-06-29 | 38 | 36.0 | 5.900263157894737 | 5.9 | 5.9 | 0.0 |
| RS | 2025-07-06 | 38 | 36.0 | 6.024736842105263 | 6.02 | 6.02 | 0.0 |
| RS | 2025-07-13 | 37 | 36.0 | 6.021351351351351 | 6.02 | 6.01 | -0.0099999999999997 |
| RS | 2025-07-20 | 38 | 36.0 | 5.941052631578947 | 5.94 | 5.92 | -0.0200000000000004 |
| RS | 2025-08-10 | 37 | 36.0 | 5.865135135135135 | 5.86 | 5.86 | 0.0 |
| RS | 2025-08-17 | 37 | 36.0 | 5.875675675675676 | 5.87 | 5.87 | 0.0 |
| RS | 2025-08-24 | 37 | 36.0 | 5.841891891891892 | 5.84 | 5.83 | -0.0099999999999997 |
| RS | 2025-08-31 | 37 | 36.0 | 5.848648648648648 | 5.84 | 5.85 | 0.0099999999999997 |
| RS | 2025-09-07 | 37 | 36.0 | 5.8878378378378375 | 5.88 | 5.88 | 0.0 |
| RS | 2025-09-14 | 37 | 36.0 | 5.942702702702703 | 5.94 | 5.94 | 0.0 |
| RS | 2025-09-21 | 1 | ausente | 6.19 | 6.19 | ausente | ausente |
| RS | 2025-09-28 | 37 | 36.0 | 6.135675675675676 | 6.13 | 6.13 | 0.0 |
| RS | 2025-10-05 | 37 | 36.0 | 6.208378378378379 | 6.2 | 6.2 | 0.0 |
| RS | 2025-10-12 | 37 | 36.0 | 6.209729729729729 | 6.21 | 6.21 | 0.0 |
| MA | 2024-06-30 | 20 | 19.0 | 5.4615 | 5.46 | 5.46 | 0.0 |
| MA | 2024-07-07 | 23 | 22.0 | 5.773913043478261 | 5.77 | 5.76 | -0.0099999999999997 |
| MA | 2024-07-14 | 22 | 21.0 | 5.843181818181819 | 5.84 | 5.84 | 0.0 |
| MA | 2024-07-21 | 23 | 22.0 | 5.839130434782609 | 5.83 | 5.83 | 0.0 |
| MA | 2024-07-28 | 22 | 21.0 | 5.800454545454546 | 5.8 | 5.79 | -0.0099999999999997 |
| MA | 2024-08-04 | 23 | 22.0 | 5.825217391304348 | 5.82 | 5.82 | 0.0 |
| MA | 2024-08-18 | 23 | 22.0 | 5.774782608695652 | 5.77 | 5.77 | 0.0 |
| MA | 2024-08-25 | 22 | 21.0 | 5.71409090909091 | 5.71 | 5.71 | 0.0 |
| MA | 2024-09-01 | 23 | 22.0 | 5.684347826086957 | 5.68 | 5.68 | 0.0 |
| MA | 2024-09-08 | 23 | 22.0 | 5.664782608695652 | 5.66 | 5.66 | 0.0 |
| MA | 2024-09-15 | 23 | 22.0 | 5.680434782608696 | 5.68 | 5.68 | 0.0 |
| MA | 2024-09-22 | 23 | 22.0 | 5.596521739130435 | 5.59 | 5.59 | 0.0 |
| MA | 2024-09-29 | 21 | 20.0 | 5.551904761904762 | 5.55 | 5.55 | 0.0 |
| MA | 2024-10-13 | 23 | 22.0 | 5.54 | 5.54 | 5.53 | -0.0099999999999997 |
| MA | 2024-10-20 | 23 | 22.0 | 5.5291304347826085 | 5.52 | 5.52 | 0.0 |
| MA | 2024-11-03 | 23 | 22.0 | 5.548260869565217 | 5.54 | 5.54 | 0.0 |
| MA | 2024-11-10 | 23 | 22.0 | 5.444347826086957 | 5.44 | 5.43 | -0.0100000000000006 |
| MA | 2024-11-17 | 22 | 21.0 | 5.530909090909091 | 5.53 | 5.52 | -0.0100000000000006 |
| MA | 2024-11-24 | 21 | 20.0 | 5.483809523809524 | 5.48 | 5.47 | -0.0100000000000006 |
| MA | 2024-12-01 | 22 | 21.0 | 5.657727272727272 | 5.65 | 5.66 | 0.0099999999999997 |

### Procedimentos e registros verificáveis

09_reproduction/reproduce.py cria o ambiente novo e compara saídas;08_environment/requirements.lock.txt fixa dependências;01_protocol/freeze.json contém hashes e autorização;03_data/raw/*.source.json contém URLs, datas, bytes e hashes. A falha inicial está em07_validation/independent_confirmation_checks_initial_failure.json e a emenda em00_governance/postfreeze_amendments.md. A regra de viabilidade de 20 capitais vem da decisão inicial A5-D01, cujo texto está preservado em `00_governance/orchestrator_01_response_dom.txt`. O protocolo congelado não foi alterado retrospectivamente.

### Correção da entrada do programa principal

clean_station_weeks remove somente linhas integralmente idênticas, registra quantidade e depois rejeita conflitos. Dados reais: zero duplicatas. Seis testes desse caminho passaram. Todas as22saídas científicas preexistentes permaneceram byte a byte iguais após reexecução integral. Os relatórios estão em07_validation/entrypoint_duplicate_checks.json epost_review_02_output_comparison.json.


### Reprodução limpa da versão corrigida

Nova execução em clean_run_final reproduziu23arquivos de resultados e4figuras,27comparaçõesbyte a byte, além do recálculo independente.

```json
{
  "created_at": "2026-09-06T01:07:10.516985+00:00",
  "seconds": 106.47916391599574,
  "clean_target": "09_reproduction/clean_run_final",
  "derived_inputs_reused": false,
  "fresh_venv": true,
  "raw_sources": "byte-preserved files with SHA-256 verified by execution; no new network acquisition",
  "checks": {
    "05_results/confirmation/contrasts_all_available.csv": true,
    "05_results/confirmation/eligible_contrasts.csv": true,
    "05_results/confirmation/by_capital.csv": true,
    "05_results/confirmation/sensitivity_summary.csv": true,
    "05_results/confirmation/sensitivity_by_capital.csv": true,
    "05_results/confirmation/coverage_all_expected.csv": true,
    "05_results/confirmation/collection_gap_counts.csv": true,
    "05_results/confirmation/collection_weekday_counts.csv": true,
    "05_results/confirmation/official_level_reconciliation.csv": true,
    "05_results/confirmation/official_change_decomposition.csv": true,
    "05_results/confirmation/supplemental_block_resampling.json": true,
    "05_results/confirmation/summary.json": true,
    "05_results/confirmation/diagnostics_summary.json": true,
    "05_results/confirmation/reconciliation_exceptions.csv": true,
    "05_results/confirmation/gap_distribution_by_capital.csv": true,
    "05_results/confirmation/weekday_distribution_by_capital.csv": true,
    "05_results/confirmation/sample_size_by_capital.csv": true,
    "05_results/confirmation/observed_monthly_counts.csv": true,
    "05_results/confirmation/official_components_same_support.csv": true,
    "05_results/confirmation/official_components_same_support.json": true,
    "05_results/confirmation/official_support_by_capital.csv": true,
    "05_results/confirmation/official_exceptions_complete.csv": true,
    "05_results/confirmation/input_duplicate_audit.json": true,
    "06_manuscript/figures/figure_1_capitals.png": true,
    "06_manuscript/figures/figure_2_weekly.png": true,
    "06_manuscript/figures/figure_3_distribution.png": true,
    "06_manuscript/figures/figure_4_coverage.png": true
  },
  "independent_all_pass": true,
  "all_pass": true
}
```


## Nota da edição de reprodução pública

Esta cópia mantém os resultados e tabelas do suplemento. Foram substituídos somente caminhos absolutos da máquina original por caminhos relativos. Os registros de conversas e governança mencionados no texto pertencem ao acervo privado e não acompanham esta edição; consulte a síntese PROVENIENCIA.md. O comando atual desta edição é reproduzir.py, documentado no README.md. A reprodução descrita historicamente acima não deve ser confundida com uma reprodução externa por terceiros.
