# Relato de reprodução ou divergência

Este arquivo é um modelo local. Preenchê-lo não envia informações a nenhum serviço. Guarde a tentativa antes de corrigir qualquer problema.

- Identificador da edição / SHA-256 do ZIP:
- Data da tentativa:
- Resultado: sucesso / falha de instalação / saída divergente / outro:
- Sistema e arquitetura (sem nome do computador ou usuário):
- Versão do Python:
- Comando utilizado:
- Etapa em que parou, se aplicável:
- `status` e `all_pass` do relatório:
- Quais comparações falharam:
- Valor esperado e valor observado:
- Passos mínimos para reproduzir o problema:
- Houve alteração de código, dados ou dependências? Descreva:
- Observações metodológicas, separadas de problemas de instalação:
- Identificador opcional do relator (pode ser pseudônimo):

O `relatorio.json` foi projetado para evitar caminhos pessoais. Mesmo assim, revise o conteúdo antes de compartilhá-lo. Logs brutos e imagens da tela podem conter nomes de usuário, caminhos, identificadores de máquina ou informações de rede; não os publique integralmente sem revisão. Não envie credenciais ou documentos pessoais.

O canal público e as condições de recebimento de relatos serão definidos na etapa de publicação. Este candidato local não cria formulários externos, contas, issues ou notificações.
