# Artigo 5 — reprodução dos resultados sobre gasolina

**Edição 1.0.0 — pacote público com aquisição direta dos dados oficiais.** Esta edição permite recalcular os resultados confirmatórios, a validação independente e as quatro figuras do estudo a partir dos oito arquivos oficiais congelados da ANP.

O artigo compara duas formas de calcular variações semanais de preços: médias de amostras sucessivas e médias das mudanças nos mesmos cadastros. Não mede inflação de consumo, causalidade ou erro institucional.

## Comece aqui

1. Extraia o ZIP inteiro. Não execute o programa dentro do arquivo compactado.
2. Abra um terminal na pasta `artigo-05-reproducao`.
3. Confira os arquivos, sem instalar nada:

```bash
python3.14 reproduzir.py --verificar
```

4. Inicie uma execução nova:

```bash
python3.14 reproduzir.py
```

O programa cria um ambiente Python novo, instala dependências com versões e hashes fixos, copia somente entradas científicas para um espaço isolado e executa sete etapas. Não pede contas, credenciais, GPU, Word, LibreOffice ou acesso a conversas de IA. Os oito dados brutos não são redistribuídos no ZIP: o programa os baixa diretamente das URLs oficiais da ANP e exige os mesmos tamanhos e hashes do acervo congelado antes de executar. Se a fonte estiver indisponível ou tiver mudado, a análise é interrompida. A instalação das bibliotecas usa internet e o PyPI oficial.

Ao terminar, deve aparecer:

```text
SUCESSO: 27 saídas conferidas, recálculo independente e testes de duplicatas aprovados.
Relatório: execucoes/reproducao-001/relatorio.json
```

O relatório deve ter `status: passed` e `all_pass: true`. As 27 comparações, as verificações independentes e os testes de duplicatas devem ser verdadeiros. Uma execução que termina com erro ou apresenta qualquer comparação falsa não é aprovada.

## Requisitos e limites de portabilidade

- Linux x86_64 e CPython 3.14 com o módulo `venv` e instalação de pip no ambiente criado.
- Internet para obter aproximadamente 104 MB de dados da ANP e as dependências do PyPI na primeira execução.
- Pelo menos 1 GiB de espaço livre. Reserve mais espaço para guardar várias execuções.
- A execução científica pode levar vários minutos, além do download dos dados e das bibliotecas. O tempo varia por máquina e conexão.
- Windows nativo, macOS, ARM e outras versões de Python não foram validados nesta edição. Linux em WSL é um caminho possível, mas não foi testado aqui. O programa rejeita plataformas diferentes antes de executar a análise.

## Onde ficam os resultados

Cada execução fica em `execucoes/<nome>/`. A subpasta `trabalho` contém os dados copiados, código, saídas e validações daquela execução; `logs` contém o diagnóstico de cada etapa. A pasta `referencia` do pacote contém apenas os resultados esperados, usados **depois** do recálculo para comparação. Ela não é copiada para o espaço de trabalho.

O programa recusa sobrescrever uma execução. Para repetir:

```bash
python3.14 reproduzir.py --nome repeticao-002
```

O conteúdo científico é recalculado. Horários, tempo e consumo de recursos não precisam coincidir. As 23 saídas determinísticas e quatro PNGs precisam corresponder aos hashes registrados. Um resultado diferente merece investigação; não ajuste o manifesto apenas para transformar a falha em sucesso.

## Leitura e rastreabilidade

| Material | Local |
|---|---|
| Manuscrito PDF e fonte textual | `06_manuscript/` |
| Suplemento com limites e resultados adversos | `06_manuscript/supplement.md` |
| Protocolo congelado e identificação original das entradas | `01_protocol/` |
| Origens e hashes dos dados a adquirir | `FONTES_DADOS.json`; arquivos baixados em `03_data/raw/` |
| Código científico preservado | `04_code/` |
| Resultados esperados e figuras | `referencia/` |
| Participação das IAs, participação humana e limites da verificação | `PROVENIENCIA.md` e `proveniencia.json` |
| Versões e hashes das dependências | `08_environment/` |
| Integridade dos arquivos desta edição | `MANIFESTO.json` e `SHA256SUMS.txt` |
| Formulário local para relatar uma tentativa | `RELATAR_REPRODUCAO.md` |
| Preparação editorial e condições de distribuição | `EDICAO_PUBLICA.md` e `CONDICOES_DE_USO.md` |

Os hashes existentes em `freeze.json` são o registro histórico do congelamento. Alguns códigos foram corrigidos posteriormente, conforme as emendas declaradas; eles não devem ser apresentados como idênticos às versões anteriores ao congelamento. Os hashes dos arquivos efetivamente distribuídos estão no manifesto desta edição.

## Se algo der errado

- **Python 3.14 não encontrado:** prepare o ambiente compatível antes de executar; não substitua versões silenciosamente.
- **Arquivo divergente ou ausente:** extraia uma cópia nova e confira o SHA-256 do ZIP. Não misture pastas de versões diferentes.
- **Dependência não instalada:** verifique conexão e o log de `dependencias`; as versões precisam continuar disponíveis no PyPI.
- **Saída divergente:** preserve o relatório e registre a primeira etapa com erro, o sistema, a versão e as comparações que falharam.
- **Fonte da ANP mudou:** não substitua o acervo congelado por um arquivo diferente. Isso produziria outra edição da análise.

Para baixar antecipadamente os arquivos de dados, `python3.14 obter_dados.py` tenta recuperá-lo das URLs registradas e só o aceita se tamanho e SHA-256 forem os mesmos. A disponibilidade futura das fontes não é garantida. Se você já possui os oito arquivos congelados, pode colocá-los em `03_data/raw/`: serão conferidos e não serão substituídos. Para instalação offline das bibliotecas, é possível usar `--wheels /caminho/da/pasta` com as distribuições exatas autorizadas pelo arquivo de dependências.

A reprodução computacional não demonstra, por si só, a adequação científica do método. Esta edição não comprova reprodução externa por outro pesquisador e não reconstitui o processo histórico de escolha da pergunta ou as conversas de revisão.

## Licenças e atribuição

Código próprio: MIT (`LICENSE-CODE.txt`). Texto e figuras próprios: CC BY 4.0 (`LICENSE-CONTENT.md`). Identificação pública para atribuição: **Pesquisa com IA**. Dados da ANP, bibliotecas e obras citadas mantêm suas próprias condições; veja `CONDICOES_DE_USO.md`.
