# Licença do conteúdo próprio

© 2026 Pesquisa com IA. O texto e as figuras próprios desta edição são disponibilizados sob Creative Commons Atribuição 4.0 Internacional (CC BY 4.0).

Texto jurídico completo: https://creativecommons.org/licenses/by/4.0/legalcode.pt
Resumo: https://creativecommons.org/licenses/by/4.0/deed.pt-br

Atribuição sugerida: “Pesquisa com IA. Artigo 5 — Gasolina comum e comparabilidade semanal. Pacote de reprodução 1.0.0, 2026. https://pesquisacomia.com.br/pesquisa-05.html. CC BY 4.0.” Indique alterações feitas e mantenha o link da licença. Não sugira endosso do projeto.

Esta licença abrange as contribuições próprias de texto, documentação científica, tabelas e figuras, na medida dos direitos que o responsável possa conceder. Não reivindica direitos sobre fatos, dados públicos, citações, obras de terceiros ou material sem proteção autoral. Código próprio segue a licença MIT; dados ANP e bibliotecas mantêm suas condições próprias. A identificação pública para atribuição é Pesquisa com IA.
