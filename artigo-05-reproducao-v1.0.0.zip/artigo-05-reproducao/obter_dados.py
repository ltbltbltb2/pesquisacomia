"""Obtém as oito fontes oficiais, sem substituir arquivos existentes ou aceitar dados alterados."""
from pathlib import Path
import hashlib
import json
import os
import re
import sys
import tempfile
import urllib.request
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent

def valid_url(url):
    u = urlsplit(url)
    return (u.scheme == 'https' and u.netloc == 'www.gov.br' and
            u.path.startswith('/anp/') and not u.fragment)

class OfficialRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not valid_url(newurl):
            raise ValueError('Redirecionamento fora da fonte oficial; aquisição interrompida.')
        return super().redirect_request(req, fp, code, msg, headers, newurl)

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def acquire(root=ROOT):
    sources = json.loads((root/'FONTES_DADOS.json').read_text())['files']
    if len(sources) != 8 or len({x['file'] for x in sources}) != 8:
        raise ValueError('São necessárias oito fontes distintas.')
    for item in sources:
        if not re.fullmatch(r'[A-Za-z0-9_.-]+', item['file']) or item['file'] in ('.','..'):
            raise ValueError('Nome de arquivo inválido.')
        if not valid_url(item['url']) or not re.fullmatch(r'[0-9a-f]{64}', item['sha256']):
            raise ValueError('Fonte ou identificação inválida.')
        if not isinstance(item['bytes'], int) or not 0 < item['bytes'] <= 100*1024*1024:
            raise ValueError('Tamanho de fonte inválido.')
    rawdir = root/'03_data/raw'
    if (root/'03_data').is_symlink() or rawdir.is_symlink():
        raise ValueError('A pasta de dados não pode ser um link simbólico.')
    rawdir.mkdir(parents=True, exist_ok=True)
    opener = urllib.request.build_opener(OfficialRedirect())
    for item in sources:
        target = rawdir/item['file']
        if os.path.lexists(target):
            if target.is_symlink() or not target.is_file() or target.stat().st_size != item['bytes'] or digest(target) != item['sha256']:
                raise ValueError('Arquivo existente diverge; não será sobrescrito: '+target.name)
            print('Já conferido: '+target.name, flush=True)
            continue
        fd, name = tempfile.mkstemp(prefix='download-', suffix='.part', dir=rawdir)
        try:
            h = hashlib.sha256(); size = 0
            request = urllib.request.Request(item['url'], headers={'User-Agent':'Pesquisa-com-IA-reproducao/1.0'})
            with os.fdopen(fd, 'wb') as out, opener.open(request, timeout=30) as response:
                if not valid_url(response.geturl()): raise ValueError('Resposta fora da fonte oficial.')
                while block := response.read(1024*1024):
                    size += len(block)
                    if size > item['bytes']: raise ValueError('A fonte mudou de tamanho: '+target.name)
                    h.update(block); out.write(block)
            if size != item['bytes'] or h.hexdigest() != item['sha256']:
                raise ValueError('A fonte não corresponde ao acervo congelado: '+target.name)
            # A criação atômica falha se outro processo já criou o destino.
            os.link(name, target)
            print('Baixado e conferido: '+target.name, flush=True)
        finally:
            if os.path.exists(name): os.unlink(name)
    print('Oito fontes verificadas.', flush=True)

if __name__ == '__main__':
    try: acquire()
    except (ValueError, OSError, KeyError) as exc:
        print('Dados indisponíveis ou divergentes: '+str(exc), file=sys.stderr)
        sys.exit(1)
