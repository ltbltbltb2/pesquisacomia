"""Reprodução isolada dos resultados confirmatórios a partir dos dados congelados."""
import argparse, datetime, hashlib, json, os, platform, re, shutil, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
STEPS = ['run_confirmation.py', 'validate_confirmation.py', 'make_figures.py',
         'diagnostics.py', 'supplemental_tables.py', 'reconciliation_summary.py', 'validate_entrypoint.py']

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''): h.update(block)
    return h.hexdigest()

def verify(root=ROOT):
    manifest = json.loads((root / 'MANIFESTO.json').read_text())
    expected = manifest['files']
    external = manifest['external_inputs']
    sources = json.loads((root/'FONTES_DADOS.json').read_text())['files']
    source_expected = {'03_data/raw/'+x['file']: {'sha256':x['sha256'],'bytes':x['bytes']} for x in sources}
    if len(external) != 8 or external != source_expected or set(external) & set(expected):
        raise ValueError('Inventário das oito fontes externas inconsistente.')
    for name in set(expected) | set(external):
        if name.startswith('/') or '\\' in name or any(x in ('','..','.') for x in name.split('/')):
            raise ValueError('Caminho inválido no manifesto.')
    if not expected or len(manifest['reference_outputs']) != 27:
        raise ValueError('Manifesto incompleto: são esperadas 27 saídas de referência.')
    found = set()
    for p in root.rglob('*'):
        rel = p.relative_to(root)
        if rel.parts[0] == 'execucoes': continue
        if p.is_symlink(): raise ValueError('O pacote contém um link simbólico: ' + str(rel))
        if not p.is_file(): continue
        name = rel.as_posix()
        if name in {'MANIFESTO.json', 'SHA256SUMS.txt'}: continue
        if name in external:
            if digest(p) != external[name]['sha256'] or p.stat().st_size != external[name]['bytes']:
                raise ValueError('Dado externo divergente: ' + name)
            continue
        found.add(name)
        if name not in expected or digest(p) != expected[name]['sha256'] or p.stat().st_size != expected[name]['bytes']:
            raise ValueError('Arquivo ausente do manifesto ou modificado: ' + name)
    if found != set(expected): raise ValueError('Há arquivos faltando no pacote.')
    hashes = {}
    for line in (root / 'SHA256SUMS.txt').read_text().splitlines():
        sha, name = line.split('  ', 1)
        if name in hashes or not re.fullmatch(r'[0-9a-f]{64}', sha):
            raise ValueError('Lista SHA256SUMS inválida.')
        hashes[name] = sha
    if set(hashes) != set(expected) | {'MANIFESTO.json'}: raise ValueError('Lista SHA256SUMS inconsistente.')
    for name, sha in hashes.items():
        if digest(root / name) != sha: raise ValueError('SHA-256 divergente: ' + name)
    return manifest

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verificar', action='store_true', help='Conferir os arquivos sem instalar dependências ou executar análises.')
    parser.add_argument('--nome', default='reproducao-001', help='Nome de uma execução nova dentro de execucoes/.')
    parser.add_argument('--wheels', type=Path, help='Opcional: pasta local de wheels para instalar dependências sem rede.')
    args = parser.parse_args()
    manifest = verify()
    print('Integridade confirmada: {} arquivos.'.format(len(manifest['files'])), flush=True)
    if args.verificar:
        missing = sum(not (ROOT/name).is_file() for name in manifest['external_inputs'])
        print('Fontes ANP ausentes: {} de 8. A execução fará a aquisição e conferência.'.format(missing), flush=True)
        return 0
    if sys.platform != 'linux' or sys.version_info[:2] != (3, 14) or platform.machine().lower() not in ('x86_64','amd64'):
        raise ValueError('Esta edição foi preparada para Linux x86_64 com Python 3.14. Consulte README.md.')
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,59}', args.nome): raise ValueError('Use um nome simples, sem barras ou espaços.')
    output = ROOT / 'execucoes' / args.nome
    if (ROOT/'execucoes').is_symlink(): raise ValueError('A pasta de execuções não pode ser um link simbólico.')
    if output.exists(): raise ValueError('Execução já existe. Preserve-a e escolha outro --nome.')
    if args.wheels and not args.wheels.is_dir(): raise ValueError('Pasta de wheels não encontrada.')
    if shutil.disk_usage(ROOT).free < 1024 ** 3: raise ValueError('Disponibilize pelo menos 1 GiB de espaço livre.')
    # A integridade do executor e das URLs foi conferida antes de usar a rede.
    acquisition = subprocess.run([sys.executable, '-B', str(ROOT/'obter_dados.py')], cwd=ROOT)
    if acquisition.returncode: raise ValueError('Aquisição dos dados não concluída; nenhuma análise foi iniciada.')
    manifest = verify()
    if any(not (ROOT/name).is_file() for name in manifest['external_inputs']):
        raise ValueError('Os oito arquivos oficiais são obrigatórios para executar.')
    output.mkdir(parents=True)
    work = output / 'trabalho'
    for name in ['01_protocol','03_data/raw','03_data/processed','04_code','05_results/confirmation',
                 '06_manuscript/figures','07_validation','08_environment']:
        (work / name).mkdir(parents=True, exist_ok=True)
    # Apenas entradas científicas entram no espaço de trabalho. Referências ficam fora dele.
    for directory in ['01_protocol','03_data/raw','04_code','08_environment']:
        for p in (ROOT / directory).iterdir():
            if p.is_file(): shutil.copy2(p, work / directory / p.name)
    logs = output / 'logs'; logs.mkdir()
    report = {'status':'running','started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'python':platform.python_version(),'system':platform.system(),'machine':platform.machine(),
              'fresh_venv':True,'derived_inputs_reused':False,'external_human_reproduction':False,
              'dependency_source':'local wheels' if args.wheels else 'PyPI','steps':[],'comparisons':{}}
    started = time.monotonic()
    env = dict(os.environ, PYTHONHASHSEED='501', PYTHONWARNINGS='ignore', MPLBACKEND='Agg',
               MPLCONFIGDIR=str(work / '08_environment/matplotlib'))
    env.pop('PYTHONPATH',None); env.pop('PYTHONHOME',None); env['PYTHONNOUSERSITE']='1'
    def run(label, command):
        print('Executando: ' + label, flush=True)
        with (logs / (label + '.log')).open('w') as log:
            process = subprocess.run(command, cwd=work, env=env, stdout=log, stderr=subprocess.STDOUT)
        report['steps'].append({'step':label,'returncode':process.returncode})
        if process.returncode: raise ValueError('Falha em '+label+'. Consulte o log correspondente dentro desta execução.')
    try:
        run('ambiente', [sys.executable, '-m', 'venv', str(output / '.venv')])
        py = str(output / '.venv/bin/python')
        install = [py,'-m','pip','install','--disable-pip-version-check','--require-hashes','--only-binary=:all:',
                   '-r',str(work / '08_environment/requirements-public.lock.txt')]
        if args.wheels: install += ['--no-index','--find-links',str(args.wheels.resolve())]
        else: install += ['--index-url','https://pypi.org/simple']
        run('dependencias', install)
        for step in STEPS: run(Path(step).stem, [py, str(work / '04_code' / step)])
        for name, reference in manifest['reference_outputs'].items():
            produced = work / name
            report['comparisons'][name] = produced.is_file() and digest(produced) == reference['sha256']
        independent = json.loads((work/'07_validation/independent_confirmation_checks.json').read_text())
        duplicates = json.loads((work/'07_validation/entrypoint_duplicate_checks.json').read_text())
        report['independent_checks'] = independent['checks']
        report['duplicate_checks'] = duplicates['checks']
        report['resources'] = json.loads((work/'05_results/confirmation/resources.json').read_text())
        report['all_pass'] = all(report['comparisons'].values()) and independent['all_pass'] and duplicates['all_pass']
        report['status'] = 'passed' if report['all_pass'] else 'failed'
        if not report['all_pass']: raise ValueError('Uma comparação divergiu. Preserve a execução e registre a divergência.')
    except Exception:
        report['status'] = 'failed'; report['all_pass'] = False
        raise
    finally:
        report['seconds'] = round(time.monotonic() - started, 3)
        (output/'relatorio.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    print('SUCESSO: 27 saídas conferidas, recálculo independente e testes de duplicatas aprovados.', flush=True)
    print('Relatório: execucoes/'+args.nome+'/relatorio.json', flush=True)
    print('A concordância computacional não equivale a validação científica externa.', flush=True)
    return 0

if __name__ == '__main__':
    try: sys.exit(main())
    except (ValueError, OSError, KeyError) as exc:
        print('Não foi possível concluir: '+str(exc), file=sys.stderr)
        sys.exit(1)
