"""Independent scientific results from raw ZIPs, without primary aggregation functions."""
import datetime,json,math,time
from collections import defaultdict
from fractions import Fraction
from decimal import Decimal,ROUND_HALF_EVEN
from pathlib import Path
import numpy as np
import pandas as pd
from validate_core import independent_raw

root=Path(__file__).resolve().parents[1]
def main():
    if not (root/'01_protocol/freeze.json').exists():raise SystemExit('Refused: protocol not frozen')
    t=time.perf_counter();paths=sorted((root/'03_data/raw').glob('ca-2024-*.zip'))+sorted((root/'03_data/raw').glob('ca-2025-*.zip'))
    alt=independent_raw(datetime.date(2023,12,31),datetime.date(2025,12,21),paths)
    alt=alt[alt.week.between('2024-01-07','2025-12-21')].copy();alt.to_csv(root/'07_validation/independent_confirmation_raw.csv',index=False)
    p=pd.read_csv(root/'05_results/confirmation/contrasts_all_available.csv')
    m=p.merge(alt,on=['uf','week'],suffixes=('_primary','_independent'),validate='one_to_one',how='outer',indicator=True)
    checks={'pair_keys':bool(m._merge.eq('both').all())}
    for c in ['D','W','C','n_common']:checks[c]=bool(np.allclose(m[c+'_primary'],m[c+'_independent'],atol=1e-12,rtol=0,equal_nan=True))
    grouped=defaultdict(list)
    for r in alt.to_dict('records'):
        if r['n_common']>=5:grouped[r['uf']].append(r)
    theta=math.fsum(math.fsum(abs(r['C']) for r in rows)/len(rows) for rows in grouped.values())/len(grouped)
    def cl(v):
        v=Decimal(str(v)).quantize(Decimal('0.000000000001'),rounding=ROUND_HALF_EVEN)
        if v>=Decimal('.01'):return 1
        if v<=Decimal('-.01'):return -1
        return 0
    disagreement=math.fsum(sum(cl(r['D'])!=cl(r['W']) for r in rows)/len(rows) for rows in grouped.values())/len(grouped)
    material=math.fsum(sum(abs(Decimal(str(r['D'])).quantize(Decimal('0.000000000001'),rounding=ROUND_HALF_EVEN)-Decimal(str(r['W'])).quantize(Decimal('0.000000000001'),rounding=ROUND_HALF_EVEN))>=Decimal('.02') for r in rows)/len(rows) for rows in grouped.values())/len(grouped)
    weighted=sorted((abs(r['C']),Fraction(1,len(grouped)*len(rows))) for rows in grouped.values() for r in rows)
    cumulative=Fraction(0);q95=None
    for value,weight in weighted:
        cumulative+=weight
        if cumulative>=Fraction(19,20):q95=value;break
    s=json.loads((root/'05_results/confirmation/summary.json').read_text())
    derived={'mean_abs_C_equal_capitals':theta,'class_disagreement_equal_capitals':disagreement,'abs_at_least_2c_equal_capitals':material,'p95_abs_C_equal_capitals':q95}
    def cu(v):return int(Decimal(str(v)).quantize(Decimal('0.000000000001'),rounding=ROUND_HALF_EVEN)*10**12)
    def eqavg(fn):return math.fsum(sum(fn(r) for r in rows)/len(rows) for rows in grouped.values())/len(grouped)
    for cents in (1,2,5):derived[f'abs_at_least_{cents}c_equal_capitals']=eqavg(lambda r:abs(cu(r['D'])-cu(r['W']))>=cents*10**10)
    derived['opposite_direction_equal_capitals']=eqavg(lambda r:cl(r['D'])*cl(r['W'])==-1)
    derived['material_disagreement_equal_capitals']=eqavg(lambda r:cl(r['D'])!=cl(r['W']) and abs(cu(r['D'])-cu(r['W']))>=2*10**10)
    derived['mean_C_equal_capitals']=eqavg(lambda r:r['C'])
    checks['eligibility_count']=sum(map(len,grouped.values()))==s['n_pairs']
    checks['capitals']=len(grouped)==s['n_capitals']
    checks['matrix']=all(abs(eqavg(lambda r:cl(r['D'])==item['class_D'] and cl(r['W'])==item['class_W'])-item['weight'])<=1e-12 for item in s['class_matrix_equal_capitals'])
    for name,v in derived.items():checks[name]=abs(v-s[name])<=1e-12
    report={'checks':checks,'all_pass':all(checks.values()),'independent_summary':derived,'seconds':time.perf_counter()-t,'raw_pairs':len(alt),'source':'stdlib csv/Decimal over raw archives; independent math.fsum/Fraction aggregations'}
    (root/'07_validation/independent_confirmation_checks.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
    if not report['all_pass']:raise SystemExit(1)

if __name__=='__main__':main()
