"""Pre-freeze audit: development prices only; confirmation schema/coverage only."""
import collections, datetime, json, resource, time, unicodedata, zipfile
from pathlib import Path
import numpy as np
import pandas as pd
from openpyxl import load_workbook

ROOT=Path(__file__).resolve().parents[1]
CAPITALS=dict(AC='RIO BRANCO',AL='MACEIO',AP='MACAPA',AM='MANAUS',BA='SALVADOR',CE='FORTALEZA',DF='BRASILIA',ES='VITORIA',GO='GOIANIA',MA='SAO LUIS',MT='CUIABA',MS='CAMPO GRANDE',MG='BELO HORIZONTE',PA='BELEM',PB='JOAO PESSOA',PR='CURITIBA',PE='RECIFE',PI='TERESINA',RJ='RIO DE JANEIRO',RN='NATAL',RS='PORTO ALEGRE',RO='PORTO VELHO',RR='BOA VISTA',SC='FLORIANOPOLIS',SP='SAO PAULO',SE='ARACAJU',TO='PALMAS')
def norm(x): return ''.join(c for c in unicodedata.normalize('NFKD',str(x).upper()) if not unicodedata.combining(c)).strip()
def load_year(year, prices=False, development_boundary=False, confirmation_unlocked=False):
    if prices and year!=2023 and not (year==2024 and development_boundary):
        if not confirmation_unlocked or not (ROOT/'01_protocol/freeze.json').exists():raise RuntimeError('Confirmation price lock: pre-freeze audit only')
    frames=[]; meta=[]
    cols=['Estado - Sigla','Municipio','CNPJ da Revenda','Produto','Data da Coleta','Unidade de Medida','Nome da Rua','Numero Rua']
    if prices: cols+=['Valor de Venda']
    for path in sorted((ROOT/'03_data/raw').glob(f'ca-{year}-*.zip')):
        n=0; cats=collections.Counter(); units=collections.Counter()
        with zipfile.ZipFile(path) as z:
            for member in z.namelist():
                if not member.lower().endswith('.csv'):continue
                for df in pd.read_csv(z.open(member),sep=';',encoding='utf-8-sig',dtype=str,usecols=cols,chunksize=100000):
                    n+=len(df);cats.update(df.Produto.value_counts().to_dict());units.update(df['Unidade de Medida'].value_counts().to_dict())
                    df=df[df.Produto.eq('GASOLINA')].copy()
                    df['city']=df.Municipio.map(norm);df['uf']=df['Estado - Sigla'];df=df[df.city.eq(df.uf.map(CAPITALS))].copy()
                    df['id']=df['CNPJ da Revenda'].str.replace(r'\D','',regex=True)
                    df['date']=pd.to_datetime(df['Data da Coleta'],format='%d/%m/%Y',errors='raise')
                    df['week']=df.date-pd.to_timedelta((df.date.dt.dayofweek+1)%7,unit='D')
                    if development_boundary: df=df[df.week.dt.year.eq(2023)].copy()
                    df['address']=df['Nome da Rua'].map(norm)+' '+df['Numero Rua'].fillna('').map(norm)
                    if prices:df['price']=pd.to_numeric(df['Valor de Venda'].str.replace(',','.',regex=False),errors='raise')
                    frames.append(df[['uf','city','id','date','week','address','Unidade de Medida']+(['price'] if prices else [])])
        meta.append(dict(file=path.name,rows=n,products=dict(cats),units=dict(units)))
    return pd.concat(frames,ignore_index=True),meta

def main():
    start=time.perf_counter();out=ROOT/'07_validation';out.mkdir(exist_ok=True)
    audit={};weekly=[];transitions=[];all_structural=[]
    for year in (2023,2024,2025):
        df,files=load_year(year,prices=year==2023)
        dup=df.duplicated(['uf','id','week'],keep=False)
        audit[str(year)]=dict(files=files,capital_rows=len(df),dates=[str(df.date.min()),str(df.date.max())],invalid_ids=int((df.id.str.len()!=14).sum()),duplicated_station_weeks=int(dup.sum()),id_multiple_cities=int((df.groupby('id').city.nunique()>1).sum()),id_multiple_addresses=int((df.groupby('id').address.nunique()>1).sum()),units=df['Unidade de Medida'].value_counts().to_dict())
        if dup.any():df.loc[dup].drop(columns=['price'],errors='ignore').to_csv(out/f'duplicates_{year}_structural.csv',index=False)
        all_structural.append(df.drop(columns=['price'],errors='ignore'))
        if year==2023:
            boundary,_=load_year(2024,prices=True,development_boundary=True)
            df=pd.concat([df,boundary],ignore_index=True)
            df.to_csv(ROOT/'03_data/processed/development_2023.csv',index=False)
        print(year,audit[str(year)]['capital_rows'],'capital records; duplicated station-weeks',int(dup.sum()),flush=True)
    structural=pd.concat(all_structural,ignore_index=True)
    audit['union']={'rows':len(structural),'duplicated_station_weeks':int(structural.duplicated(['uf','id','week'],keep=False).sum()),'id_multiple_cities':int((structural.groupby('id').city.nunique()>1).sum()),'id_multiple_addresses':int((structural.groupby('id').address.nunique()>1).sum())}
    structural.to_csv(ROOT/'03_data/processed/structural_all_years_no_prices.csv',index=False)
    if audit['union']['duplicated_station_weeks']:raise RuntimeError('Union has duplicate station-weeks; investigate before proceeding')
    for year in (2023,2024,2025):
        current=structural[structural.week.dt.year.eq(year)]
        groups={(uf,w):g for (uf,w),g in structural.groupby(['uf','week'])}
        for (uf,w),g in current.groupby(['uf','week']):
            weekly.append(dict(year=year,uf=uf,week=str(w.date()),n=len(g)))
            prev=groups.get((uf,w-pd.Timedelta(days=7)))
            if prev is None:continue
            match=g.merge(prev,on='id',suffixes=('_now','_prev'))
            gaps=(match.date_now-match.date_prev).dt.days
            transitions.append(dict(year=year,uf=uf,week=str(w.date()),n_current=len(g),n_previous=len(prev),n_common=len(match),same_weekday=int((gaps==7).sum()),gap_min=None if len(gaps)==0 else int(gaps.min()),gap_max=None if len(gaps)==0 else int(gaps.max())))
    pd.DataFrame(weekly).to_csv(out/'structural_weekly_counts.csv',index=False)
    pd.DataFrame(transitions).to_csv(out/'structural_overlap.csv',index=False)
    # Read only calendar fields from confirmation aggregate (never retain prices).
    calendars=[];official=[]
    for filename in ('semanal-municipios-2022_a_2023.xlsx','semanal-municipio-2024-2025.xlsx'):
        wb=load_workbook(ROOT/'03_data/raw'/filename,read_only=True,data_only=True)
        for sh in wb:
            for row in sh.iter_rows(values_only=True):
                if len(row)<9 or not isinstance(row[0],datetime.datetime):continue
                begin,end=row[:2]
                if begin.year not in (2023,2024,2025):continue
                calendars.append((begin.date().isoformat(),end.date().isoformat()))
                if begin.year==2023 and norm(row[4]) in CAPITALS.values() and row[5]=='GASOLINA COMUM':
                    official.append(dict(week=begin.date().isoformat(),end=end.date().isoformat(),city=norm(row[4]),n=row[6],unit=row[7],mean=row[8]))
        wb.close()
    cal=pd.DataFrame(sorted(set(calendars)),columns=['week','end']);cal.to_csv(out/'official_calendar.csv',index=False)
    audit['official_calendar']={'weeks':len(cal),'all_sunday':bool(pd.to_datetime(cal.week).dt.dayofweek.eq(6).all()),'all_seven_days':bool((pd.to_datetime(cal.end)-pd.to_datetime(cal.week)).dt.days.eq(6).all())}
    pd.DataFrame(official).to_csv(out/'official_development_2023.csv',index=False)
    audit['resources']={'seconds':time.perf_counter()-start,'peak_rss_MiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024}
    (out/'prefreeze_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
    print('Complete',audit['resources'],audit['official_calendar'], 'development official rows',len(official),flush=True)

if __name__=='__main__':main()
