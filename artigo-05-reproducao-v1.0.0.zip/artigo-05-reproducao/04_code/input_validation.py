"""Frozen duplicate policy shared by the main entry point and its tests."""
def clean_station_weeks(frame):
    cleaned=frame.drop_duplicates().copy();removed=len(frame)-len(cleaned)
    if cleaned.duplicated(['uf','id','week']).any():raise ValueError('Conflicting station-week key after exact duplicates removed')
    return cleaned,{'input_rows':len(frame),'exact_duplicate_rows_removed':removed,'retained_rows':len(cleaned)}
