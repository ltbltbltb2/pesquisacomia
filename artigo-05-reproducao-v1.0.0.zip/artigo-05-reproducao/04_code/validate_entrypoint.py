from pathlib import Path
import pandas as pd,json,inspect
from input_validation import clean_station_weeks
import run_confirmation
root=Path(__file__).resolve().parents[1]
d=pd.read_csv(root/'03_data/processed/confirmation_station_weeks.csv',dtype={'id':str},parse_dates=['date','week'])
clean,a=clean_station_weeks(d);aug=pd.concat([d,d.iloc[:3]],ignore_index=True);recovered,b=clean_station_weeks(aug)
checks={'main_uses_tested_input_path':'d,duplicate_report=clean_station_weeks(d)' in inspect.getsource(run_confirmation.main),'unchanged_real_input':clean.equals(d),'zero_actual_duplicates':a['exact_duplicate_rows_removed']==0,'exact_duplicate_invariance':recovered.equals(d),'removed_count':b['exact_duplicate_rows_removed']==3}
conflict=pd.concat([d,d.iloc[:1].assign(price=lambda v:v.price+.001)],ignore_index=True)
try:clean_station_weeks(conflict);checks['conflict_rejected']=False
except ValueError:checks['conflict_rejected']=True
report={'checks':checks,'all_pass':all(checks.values()),'actual_input':a,'synthetic_augmentation':b};(root/'07_validation/entrypoint_duplicate_checks.json').write_text(json.dumps(report,indent=2));print(report)
if not report['all_pass']:raise SystemExit(1)
