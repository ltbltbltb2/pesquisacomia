"""Scientific invariants and independent raw-record recomputation (stdlib)."""
import csv,datetime,io,json,time,zipfile
from collections import defaultdict
from decimal import Decimal
from pathlib import Path
import numpy as np
import pandas as pd
from audit_data import CAPITALS,norm
from analysis_core import contrasts,summarize,classify,at_least,weighted_quantile,empirical_q,categorical_discrepancy

ROOT=Path(__file__).resolve().parents[1]
def independent_raw(start,end,paths):
    groups=defaultdict(dict)
    for path in paths:
        with zipfile.ZipFile(path) as archive:
            for name in archive.namelist():
                if not name.endswith('.csv'):continue
                for r in csv.DictReader(io.TextIOWrapper(archive.open(name),encoding='utf-8-sig'),delimiter=';'):
                    if r['Produto']!='GASOLINA' or norm(r['Municipio'])!=CAPITALS.get(r['Estado - Sigla']):continue
                    date=datetime.datetime.strptime(r['Data da Coleta'],'%d/%m/%Y').date()
                    week=date-datetime.timedelta(days=(date.weekday()+1)%7)
                    if not start<=week<=end:continue
                    identifier=''.join(c for c in r['CNPJ da Revenda'] if c.isdigit()); key=(r['Estado - Sigla'],week)
                    val=Decimal(r['Valor de Venda'].replace(',','.'))
                    if identifier in groups[key] and groups[key][identifier]!=val:raise ValueError('Conflicting raw price')
                    groups[key][identifier]=val
    result=[]
    for (uf,week),now in sorted(groups.items()):
        old=groups.get((uf,week-datetime.timedelta(days=7)))
        if not old:continue
        common=now.keys()&old.keys()
        d=sum(now.values())/len(now)-sum(old.values())/len(old)
        w=sum((now[i]-old[i] for i in common),Decimal(0))/len(common) if common else None
        result.append(dict(uf=uf,week=str(week),D=float(d),W=float(w) if w is not None else None,C=float(d-w) if w is not None else None,n_common=len(common)))
    return pd.DataFrame(result)

def main():
    t=time.perf_counter();checks={}
    def frame(rows):
        return pd.DataFrame([dict(uf='XX',id=i,week=pd.Timestamp(w),date=pd.Timestamp(w)+pd.Timedelta(days=1),address=i,price=p) for w,i,p in rows])
    w0='2023-01-01';w1='2023-01-08'
    x=frame([(w0,'a',4),(w0,'b',6),(w1,'a',7),(w1,'b',5)])
    r=contrasts(x,1);checks['fixed_set_composition_zero']=bool(np.allclose(r.C,0))
    x.loc[(x.id=='b')&(x.week==pd.Timestamp(w1)),'date']+=pd.Timedelta(days=1)
    restricted=contrasts(x,1)
    checks['restricted_comparator_can_differ_without_rotation']=bool(np.allclose(restricted.C,0) and not np.allclose(restricted.D-restricted.W_same_day,0) and np.allclose(restricted.D-restricted.W_same_day,restricted.C+restricted.W-restricted.W_same_day))
    x=frame([(w0,'a',4),(w0,'b',6),(w1,'b',6),(w1,'c',8)])
    r=contrasts(x,1);checks['constant_individual_prices_rotation']=bool(np.allclose(r.W,0) and np.allclose(r.D,2) and np.allclose(r.C,2))
    boundaries=[-.010000001,-.01,-.009999999,0,.009999999,.01,.010000001]
    checks['classification_boundaries']=bool(np.array_equal(classify(boundaries),[-1,-1,0,0,0,1,1]))
    checks['material_boundary']=bool(np.array_equal(at_least([.019999999,.02,.020000001],.02),[False,True,True]))
    checks['opposite_classes_imply_material_discrepancy']=all(abs(a-b)>=.02-1e-12 for a in boundaries for b in boundaries if classify([a])[0]*classify([b])[0]==-1)
    checks['A5_D02_opposition_rounding']=all(classify([a])[0]*classify([-a])[0]==-1 and abs(categorical_discrepancy([a],[-a])[0])>=2*10**10 for a in [.0099999999996,-.0099999999996])
    checks['overlap_must_cover_both_samples']=(10/min(10,100)==1 and 10/max(10,100)<.8)
    checks['weighted_quantile_inverse_ecdf']=weighted_quantile([1,2,3],[.1,.8,.1],.9)==2
    checks['empirical_q_ties']=empirical_q(5.1295)==5.13 and empirical_q(5.1285)==5.12 and empirical_q(5.12949999)==5.12
    dev=pd.read_csv(ROOT/'03_data/processed/development_2023.csv',dtype={'id':str},parse_dates=['week','date'])
    r=contrasts(dev)
    cut=pd.Timestamp('2023-07-02');prefix=contrasts(dev[dev.week.le(cut)])
    edited=dev.copy();edited.loc[edited.week.gt(cut),'price']*=10
    changed=contrasts(edited);left=r[r.week.le(cut)].reset_index(drop=True)
    checks['future_prices_do_not_change_past']=bool(left.equals(changed[changed.week.le(cut)].reset_index(drop=True)))
    checks['future_presence_does_not_change_past']=bool(left.equals(prefix))
    checks['row_order_invariant']=bool(r.equals(contrasts(dev.sample(frac=1,random_state=501).sort_index())))
    shuffled=contrasts(dev.sample(frac=1,random_state=502))
    checks['shuffled_numerical_invariant']=bool(np.allclose(r[['D','W','C']],shuffled[['D','W','C']],equal_nan=True,atol=1e-12))
    checks['exact_duplicate_invariant']=bool(r.equals(contrasts(pd.concat([dev,dev.iloc[:100]]))))
    conflicting=pd.concat([dev,dev.iloc[:1].assign(price=lambda q:q.price+1)])
    try:contrasts(conflicting);checks['conflicting_duplicate_rejected']=False
    except ValueError:checks['conflicting_duplicate_rejected']=True
    files=sorted((ROOT/'03_data/raw').glob('ca-2023-*.zip'))+sorted((ROOT/'03_data/raw').glob('ca-2024-*.zip'))
    alt=independent_raw(datetime.date(2023,1,1),datetime.date(2023,12,31),files)
    alt.to_csv(ROOT/'07_validation/independent_development_raw.csv',index=False)
    ref=r.copy();ref['week']=ref.week.dt.strftime('%Y-%m-%d');m=ref.merge(alt,on=['uf','week'],suffixes=('_primary','_independent'),validate='one_to_one',how='outer')
    checks['independent_same_pair_count']=len(m)==len(ref)==len(alt)
    for col in ['D','W','C','n_common']:
        checks['independent_'+col]=bool(np.allclose(m[col+'_primary'],m[col+'_independent'],equal_nan=True,atol=1e-12))
    report=dict(checks=checks,all_pass=all(checks.values()),seconds=time.perf_counter()-t,independent_pairs=len(alt),independent_starts_from='original ZIP CSV with stdlib csv and Decimal; no derived price input')
    (ROOT/'07_validation/core_tests.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
    if not report['all_pass']:raise SystemExit(1)

if __name__=='__main__':main()
