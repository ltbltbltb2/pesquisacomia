import json
from pathlib import Path
import numpy as np
import pandas as pd
from analysis_core import contrasts,summarize,block_interval

ROOT=Path(__file__).resolve().parents[1]
d=pd.read_csv(ROOT/'03_data/processed/development_2023.csv',dtype={'id':str},parse_dates=['date','week'])
r=contrasts(d);summary,per,detail=summarize(r)
out=ROOT/'05_results/development';out.mkdir(exist_ok=True)
r.to_csv(out/'contrasts.csv',index=False);per.to_csv(out/'by_capital.csv')
summary['block_intervals']=[block_interval(r,block=b,repetitions=2000) for b in (2,4,8)]
summary['identity_max_error']=float((r.C-r.composition_current+r.composition_previous).abs().max())
(out/'summary.json').write_text(json.dumps(summary,indent=2))
g=d.groupby(['city','week']).price.agg(['size','mean']).reset_index()
o=pd.read_csv(ROOT/'07_validation/official_development_2023.csv',parse_dates=['week'])
m=g.merge(o,on=['city','week'],suffixes=('_raw','_official'),how='outer',indicator=True)
m['n_diff']=m['size']-m.n;m['mean_diff']=m.mean_raw-m.mean_official
# This empirical display rule is an observed match, not an official specification.
m['empirical_display_match']=(np.floor(np.round(m.mean_raw,3)*100+1e-8)/100-m.mean_official).abs()<1e-8
m.to_csv(ROOT/'07_validation/reconciliation_2023.csv',index=False)
print(json.dumps(summary,indent=2));print(m['_merge'].value_counts());print('Count mismatches',int(m.n_diff.ne(0).sum()),'empirical display mismatches with matching counts',int((m.n_diff.eq(0)&~m.empirical_display_match).sum()))
