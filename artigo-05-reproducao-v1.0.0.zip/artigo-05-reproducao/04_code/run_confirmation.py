"""Frozen-protocol analysis; this command refuses to run without scientific freeze."""
import datetime,hashlib,json,resource,time
from pathlib import Path
import numpy as np
import pandas as pd
from openpyxl import load_workbook
from audit_data import ROOT,CAPITALS,norm,load_year
from input_validation import clean_station_weeks
from analysis_core import contrasts,summarize,block_interval,empirical_q

def main():
    frozen=ROOT/'01_protocol/freeze.json'
    if not frozen.exists():raise SystemExit('Refused: scientific protocol not frozen')
    cfg=json.loads(frozen.read_text())
    if cfg['status']!='approved' or hashlib.sha256((ROOT/cfg['protocol_file']).read_bytes()).hexdigest()!=cfg['protocol_sha256']:raise SystemExit('Refused: frozen protocol differs')
    for relative,expected in cfg['input_sha256'].items():
        h=hashlib.sha256()
        with (ROOT/relative).open('rb') as f:
            while chunk:=f.read(1024*1024):h.update(chunk)
        if h.hexdigest()!=expected:raise SystemExit('Refused: input differs from frozen acervo: '+relative)
    start=time.perf_counter();stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
    out=ROOT/'05_results/confirmation';out.mkdir(exist_ok=True)
    (out/'execution_started.json').write_text(json.dumps({'started_at':stamp,'protocol_sha256':cfg['protocol_sha256']},indent=2))
    frames=[]
    for year in (2024,2025):
        d,_=load_year(year,prices=True,confirmation_unlocked=True);frames.append(d)
    d=pd.concat(frames,ignore_index=True)
    d=d[d.week.between('2023-12-31',cfg['end_week'])].copy()
    d,duplicate_report=clean_station_weeks(d)
    (out/'input_duplicate_audit.json').write_text(json.dumps(duplicate_report,indent=2))
    if not np.isfinite(d.price).all() or (d.price<=0).any():raise ValueError('Price validity changed: diagnose before proceeding')
    d.to_csv(ROOT/'03_data/processed/confirmation_station_weeks.csv',index=False)
    r=contrasts(d);r=r[r.week.between(cfg['start_week'],cfg['end_week'])].reset_index(drop=True)
    summary,per,x=summarize(r)
    r.to_csv(out/'contrasts_all_available.csv',index=False);x.to_csv(out/'eligible_contrasts.csv',index=False)
    per=per.reindex(sorted(CAPITALS));per['expected_pairs']=103;per['coverage']=per.n/103;per['city']=pd.Series(CAPITALS)
    per.to_csv(out/'by_capital.csv')
    summary['protocol_sha256']=cfg['protocol_sha256'];summary['raw_station_week_records']=len(d);summary['expected_pairs']=27*103
    summary['identity_max_error']=float((r.C-r.composition_current+r.composition_previous).abs().max())
    summary['expanded_identity_max_error']=float((r.C-(1-r.common_fraction_current)*r.price_gap_noncommon_current+(1-r.common_fraction_previous)*r.price_gap_noncommon_previous).abs().max())
    if summary['identity_max_error']>1e-10 or summary['expanded_identity_max_error']>1e-10:raise ValueError('Identity failed')
    rows=[];sens_detail=[]
    masks={'minimum_10':r.n_common.ge(10),'overlap_both_80':r.overlap_both.ge(.8),'same_collection_weekday':r.n_same_day.ge(5),'same_address':r.n_same_address.ge(5),'without_fortaleza':r.uf.ne('CE'),'year_2024':r.week.dt.year.eq(2024),'year_2025':r.week.dt.year.eq(2025)}
    for name,mask in masks.items():
        s=r[mask&r.eligible].copy();base_summary,base_per,_=summarize(s)
        if name in ('same_collection_weekday','same_address'):
            column='W_same_day' if name=='same_collection_weekday' else 'W_same_address'
            s['comparator_change']=s.W-s[column];s['C']=s.D-s[column];s['W']=s[column]
        else:s['comparator_change']=0.
        alt_summary,alt_per,_=summarize(s)
        record={'analysis':name,'n_pairs':len(s),'n_capitals':s.uf.nunique(),'unavailable_capitals':','.join(sorted(set(CAPITALS)-set(s.uf))),'primary_same_support':base_summary['mean_abs_C_equal_capitals'],'alternative_same_support':alt_summary['mean_abs_C_equal_capitals'],'mean_abs_comparator_change':float(s.assign(v=s.comparator_change.abs()).groupby('uf').v.mean().mean()),'signed_comparator_change':float(s.groupby('uf').comparator_change.mean().mean())}
        rows.append(record)
        alt_per=alt_per.reindex(sorted(CAPITALS));alt_per['primary_same_support']=base_per.mean_abs_C;alt_per['analysis']=name;sens_detail.append(alt_per.reset_index())
    pd.DataFrame(rows).to_csv(out/'sensitivity_summary.csv',index=False);pd.concat(sens_detail).to_csv(out/'sensitivity_by_capital.csv',index=False)
    # Full expected grid, including no sample and no common observations.
    grid=pd.MultiIndex.from_product([sorted(CAPITALS),pd.date_range(cfg['start_week'],cfg['end_week'],freq='7D')],names=['uf','week']).to_frame(index=False)
    cover=grid.merge(r[['uf','week','n_now','n_old','n_common','eligible']],on=['uf','week'],how='left')
    cover['reason']=np.where(cover.n_common.isna(),'missing_sample_in_pair',np.where(cover.n_common.eq(0),'no_common',np.where(cover.n_common.lt(5),'one_to_four_common','eligible')))
    cover.to_csv(out/'coverage_all_expected.csv',index=False)
    # Calendar diagnostics are descriptive of actual records, not synchronized prices.
    groups={(uf,w):g.set_index('id') for (uf,w),g in d.groupby(['uf','week'])};gaps=[];days=[]
    for (uf,w),now in groups.items():
        if not pd.Timestamp(cfg['start_week'])<=w<=pd.Timestamp(cfg['end_week']):continue
        old=groups.get((uf,w-pd.Timedelta(days=7)))
        if old is None:continue
        common=now.index.intersection(old.index)
        for gap,n in (now.loc[common].date-old.loc[common].date).dt.days.value_counts().items():gaps.append(dict(uf=uf,week=w,gap_days=int(gap),n=int(n)))
        for side,frame in [('current',now),('previous',old)]:
            for status,ix in [('common',frame.index.intersection(common)),('noncommon',frame.index.difference(common))]:
                for day,n in frame.loc[ix].date.dt.dayofweek.value_counts().items():days.append(dict(uf=uf,week=w,side=side,status=status,weekday=int(day),n=int(n)))
    pd.DataFrame(gaps).to_csv(out/'collection_gap_counts.csv',index=False);pd.DataFrame(days).to_csv(out/'collection_weekday_counts.csv',index=False)
    # Numeric spreadsheet values retained separately from their display format.
    official=[]
    for fn in ('semanal-municipios-2022_a_2023.xlsx','semanal-municipio-2024-2025.xlsx'):
        w=load_workbook(ROOT/'03_data/raw'/fn,read_only=True,data_only=True)
        for row in w.active.iter_rows():
            v=[cell.value for cell in row]
            if len(v)<9 or not isinstance(v[0],datetime.datetime):continue
            if not pd.Timestamp('2023-12-31')<=v[0]<=pd.Timestamp(cfg['end_week']):continue
            if v[5]!='GASOLINA COMUM' or norm(v[4]) not in CAPITALS.values():continue
            official.append(dict(week=v[0],city=norm(v[4]),official_n=v[6],G=v[8],number_format=row[8].number_format))
        w.close()
    mu=d.groupby(['uf','city','week']).price.agg(mu='mean',n='size').reset_index();mu['q']=mu.mu.map(empirical_q)
    mu=mu.merge(pd.DataFrame(official),on=['city','week'],how='outer',validate='one_to_one');mu['precision_term']=mu.q-mu.mu;mu['reconciliation_residual']=mu.G-mu.q
    mu.to_csv(out/'official_level_reconciliation.csv',index=False)
    prev=mu[['uf','week','G','precision_term','reconciliation_residual']].copy();prev['week']+=pd.Timedelta(days=7)
    rec=mu.merge(prev,on=['uf','week'],suffixes=('_now','_previous')).merge(r[['uf','week','W','C','eligible']],on=['uf','week'])
    rec['official_change_minus_W']=rec.G_now-rec.G_previous-rec.W
    rec['delta_precision']=rec.precision_term_now-rec.precision_term_previous
    rec['delta_reconciliation']=rec.reconciliation_residual_now-rec.reconciliation_residual_previous
    rec['decomposition_error']=rec.official_change_minus_W-rec.C-rec.delta_precision-rec.delta_reconciliation
    rec.to_csv(out/'official_change_decomposition.csv',index=False)
    summary['official_decomposition_max_error']=float(rec.decomposition_error.abs().max())
    if summary['official_decomposition_max_error']>1e-10:raise ValueError('Official decomposition failed')
    # Supplemental only: resample actual transition vectors, never fabricate joins.
    (out/'supplemental_block_resampling.json').write_text(json.dumps([block_interval(r,b) for b in (2,4,8)],indent=2))
    (out/'summary.json').write_text(json.dumps(summary,indent=2))
    resources={'started_at':stamp,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'seconds':time.perf_counter()-start,'peak_rss_MiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024}
    (out/'resources.json').write_text(json.dumps(resources,indent=2));print(json.dumps(summary,indent=2));print(resources)

if __name__=='__main__':main()
