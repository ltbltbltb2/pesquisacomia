"""Summarize prespecified official decomposition on common eligible support."""
from pathlib import Path
import json
import pandas as pd
root=Path(__file__).resolve().parents[1];r=root/'05_results/confirmation'
d=pd.read_csv(r/'official_change_decomposition.csv');x=d[d.eligible & d[['official_change_minus_W','C','delta_precision','delta_reconciliation']].notna().all(axis=1)].copy()
rows=[]
for col in ['C','delta_precision','delta_reconciliation','official_change_minus_W']:
 per=x.assign(v=x[col],av=x[col].abs()).groupby('uf').agg(mean=('v','mean'),mean_abs=('av','mean'))
 rows.append({'component':col,'n_pairs':len(x),'n_capitals':x.uf.nunique(),'mean_equal_capitals':float(per['mean'].mean()),'mean_abs_equal_capitals':float(per.mean_abs.mean()),'max_abs':float(x[col].abs().max())})
pd.DataFrame(rows).to_csv(r/'official_components_same_support.csv',index=False)
report={'scope':'Intersection of principal eligibility and all official decomposition terms available; weights equal per capital and within-capital available transitions','n_pairs':len(x),'n_capitals':x.uf.nunique(),'unavailable_capitals':sorted(set(pd.read_csv(r/'by_capital.csv').uf)-set(x.uf)),'identity_max_error':float((x.official_change_minus_W-x.C-x.delta_precision-x.delta_reconciliation).abs().max()),'components':rows}
(r/'official_components_same_support.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
x.groupby('uf').size().rename('n_common_support').to_csv(r/'official_support_by_capital.csv')
a=pd.read_csv(r/'official_level_reconciliation.csv');valid=a.G.notna() & a.mu.notna();mismatch=~a.n.eq(a.official_n) | (a.G-a.q).abs().gt(1e-9) | ~valid
cols=['uf','city','week','n','official_n','mu','q','G','reconciliation_residual'];a.loc[mismatch,cols].to_csv(r/'official_exceptions_complete.csv',index=False)
