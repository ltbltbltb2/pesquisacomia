"""Local adjacent-week contrasts; no full-period survivor selection."""
import numpy as np
import pandas as pd
from decimal import Decimal,ROUND_HALF_EVEN,ROUND_DOWN

def empirical_q(value):
    return float(Decimal(str(round(float(value),12))).quantize(Decimal('.001'),rounding=ROUND_HALF_EVEN).quantize(Decimal('.01'),rounding=ROUND_DOWN))

def categorical_units(values):
    return np.array([int(Decimal(str(float(v))).quantize(Decimal('0.000000000001'),rounding=ROUND_HALF_EVEN)*10**12) for v in values],dtype=np.int64)

def categorical_discrepancy(d,w):
    return categorical_units(d)-categorical_units(w)

def classify(values):
    v=categorical_units(values)/10**12
    return np.where(v>=.01,1,np.where(v<=-.01,-1,0))

def at_least(values,threshold):return np.round(np.asarray(values,dtype=float),12)>=threshold

def weighted_quantile(values,weights,p):
    order=np.argsort(values,kind='stable');v=np.asarray(values)[order];w=np.asarray(weights)[order]
    cumulative=np.cumsum(w)/np.sum(w)
    return float(v[min(np.searchsorted(cumulative,p,side='left'),len(v)-1)])

def contrasts(frame,min_common=5):
    frame=frame.drop_duplicates().copy()
    if frame.duplicated(['uf','id','week']).any():raise ValueError('Ambiguous station-week records')
    groups={(uf,w):g.set_index('id') for (uf,w),g in frame.groupby(['uf','week'])}
    result=[]
    for (uf,w),now in groups.items():
        old=groups.get((uf,w-pd.Timedelta(days=7)))
        if old is None:continue
        ids=now.index.intersection(old.index);n=len(ids)
        d=float(now.price.mean()-old.price.mean())
        paired=now.loc[ids].price-old.loc[ids].price
        within=float(paired.mean()) if n else np.nan
        component=d-within
        nowgap=float(now.price.mean()-now.loc[ids].price.mean()) if n else np.nan
        oldgap=float(old.price.mean()-old.loc[ids].price.mean()) if n else np.nan
        gaps=(now.loc[ids].date-old.loc[ids].date).dt.days
        same=ids[gaps.eq(7)]
        stable=ids[now.loc[ids].address.eq(old.loc[ids].address)]
        entrants=now.index.difference(ids);leavers=old.index.difference(ids)
        gap_new=float(now.loc[entrants].price.mean()-now.loc[ids].price.mean()) if n and len(entrants) else 0. if n else np.nan
        gap_left=float(old.loc[leavers].price.mean()-old.loc[ids].price.mean()) if n and len(leavers) else 0. if n else np.nan
        result.append(dict(uf=uf,week=w,n_now=len(now),n_old=len(old),n_common=n,overlap=n/min(len(now),len(old)),common_fraction_current=n/len(now),common_fraction_previous=n/len(old),overlap_both=n/max(len(now),len(old)),eligible=n>=min_common,D=d,W=within,C=component,composition_current=nowgap,composition_previous=oldgap,price_gap_noncommon_current=gap_new,price_gap_noncommon_previous=gap_left,n_same_day=len(same),W_same_day=float((now.loc[same].price-old.loc[same].price).mean()) if len(same) else np.nan,n_same_address=len(stable),W_same_address=float((now.loc[stable].price-old.loc[stable].price).mean()) if len(stable) else np.nan))
    return pd.DataFrame(result).sort_values(['uf','week']).reset_index(drop=True)

def summarize(results):
    x=results[results.eligible].copy()
    x['absC']=x.C.abs()
    x['class_D']=classify(x.D);x['class_W']=classify(x.W)
    x['different_class']=x.class_D.ne(x.class_W)
    x['opposite_direction']=x.class_D*x.class_W==-1
    x['categorical_C_units']=categorical_discrepancy(x.D,x.W)
    for cents in (1,2,5):x[f'abs_at_least_{cents}c']=np.abs(x.categorical_C_units)>=cents*10**10
    x['material_disagreement']=x.different_class & x.abs_at_least_2c
    per=x.groupby('uf').agg(n=('C','size'),mean_abs_C=('absC','mean'),mean_C=('C','mean'),class_disagreement=('different_class','mean'),opposite_direction=('opposite_direction','mean'),material_disagreement=('material_disagreement','mean'),abs_at_least_1c=('abs_at_least_1c','mean'),abs_at_least_2c=('abs_at_least_2c','mean'),abs_at_least_5c=('abs_at_least_5c','mean'))
    per['p95_abs_C']=x.groupby('uf').absC.apply(lambda a: weighted_quantile(a,np.ones(len(a)),.95))
    summary=dict(n_pairs=len(x),n_capitals=len(per),mean_abs_C_equal_capitals=float(per.mean_abs_C.mean()),mean_C_equal_capitals=float(per.mean_C.mean()),class_disagreement_equal_capitals=float(per.class_disagreement.mean()),opposite_direction_equal_capitals=float(per.opposite_direction.mean()),p95_abs_C_pooled=float(x.absC.quantile(.95)),max_abs_C=float(x.absC.max()))
    x['weight']=1/(len(per)*x.groupby('uf').uf.transform('size'))
    summary['p95_abs_C_equal_capitals']=weighted_quantile(x.absC,x.weight,.95)
    for col in ['material_disagreement','abs_at_least_1c','abs_at_least_2c','abs_at_least_5c']:summary[col+'_equal_capitals']=float(per[col].mean())
    summary['class_matrix_equal_capitals']=[dict(class_D=i,class_W=j,weight=float(x.loc[x.class_D.eq(i)&x.class_W.eq(j),'weight'].sum())) for i in (-1,0,1) for j in (-1,0,1)]
    return summary,per,x

def block_interval(results,block=4,repetitions=4000,seed=501):
    x=results[results.eligible].copy();x['absC']=x.C.abs()
    matrix=x.pivot(index='week',columns='uf',values='absC').sort_index()
    matrix=matrix.reindex(pd.date_range(matrix.index.min(),matrix.index.max(),freq='7D'))
    a=matrix.to_numpy();n=len(a);rng=np.random.default_rng(seed);est=[]
    for _ in range(repetitions):
        starts=rng.integers(0,n,size=int(np.ceil(n/block)))
        indexes=((starts[:,None]+np.arange(block))%n).ravel()[:n]
        means=np.nanmean(a[indexes],axis=0)
        if not np.isfinite(means).all():continue
        est.append(float(means.mean()))
    return dict(block=block,repetitions=repetitions,valid_repetitions=len(est),seed=seed,lower=float(np.quantile(est,.025)),upper=float(np.quantile(est,.975)),interpretation='Temporal block resampling sensitivity; not design-based population confidence')
