from pathlib import Path
import pandas as pd
root=Path(__file__).resolve().parents[1];r=root/'05_results/confirmation'
g=pd.read_csv(r/'collection_gap_counts.csv');days=pd.read_csv(r/'collection_weekday_counts.csv');raw=pd.read_csv(root/'03_data/processed/confirmation_station_weeks.csv',usecols=['uf','week','id'])
gp=g.groupby(['uf','gap_days']).n.sum().unstack(fill_value=0);gp.to_csv(r/'gap_distribution_by_capital.csv');weekday=days.groupby(['uf','side','status','weekday']).n.sum().reset_index();weekday.to_csv(r/'weekday_distribution_by_capital.csv')
raw['month']=pd.to_datetime(raw.week).dt.to_period('M').astype(str);raw.groupby(['uf','week']).size().groupby(level=0).describe().to_csv(r/'sample_size_by_capital.csv');monthly=raw.groupby('month').agg(records=('id','size'),unique_ids=('id','nunique'));monthly.to_csv(r/'observed_monthly_counts.csv')
