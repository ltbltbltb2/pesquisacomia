"""Illustrative coverage diagnostic, not a proof for actual ANP dependence."""
import json
from pathlib import Path
import numpy as np

rng=np.random.default_rng(505);target=.02;n=103;simulations=200;reps=499;results=[]
for phi in (0.,.3,.7):
    hit={b:0 for b in (2,4,8)};width={b:[] for b in hit}
    for sim in range(simulations):
        z=np.empty(n);z[0]=rng.normal()
        for t in range(1,n):z[t]=phi*z[t-1]+np.sqrt(1-phi**2)*rng.normal()
        series=target*np.exp(.3*z-.3**2/2)
        for b in hit:
            starts=rng.integers(0,n,size=(reps,int(np.ceil(n/b))))
            inds=((starts[:,:,None]+np.arange(b))%n).reshape(reps,-1)[:,:n]
            low,high=np.quantile(series[inds].mean(axis=1),[.025,.975])
            hit[b]+=low<=target<=high;width[b].append(high-low)
    for b in hit:results.append(dict(phi=phi,block=b,empirical_coverage=hit[b]/simulations,mean_width=float(np.mean(width[b]))))
report=dict(seed=505,simulations=simulations,replicates=reps,n_weeks=n,known_mean=target,results=results,limits='Stationary lognormal AR(1) common-week toy process. Does not calibrate real ANP coverage, missingness, heterogeneity or structural breaks.')
path=Path(__file__).resolve().parents[1]/'07_validation/block_simulation.json';path.write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
