"""Inspect validity flags only; never retain/summarize held-out price levels."""
import json,zipfile
from pathlib import Path
import numpy as np
import pandas as pd
from audit_data import CAPITALS,norm

root=Path(__file__).resolve().parents[1];report=[]
for path in sorted((root/'03_data/raw').glob('ca-*.zip')):
    counts=dict(file=path.name,capital_gasoline_rows=0,missing_or_non_numeric=0,nonpositive_or_nonfinite=0)
    with zipfile.ZipFile(path) as z:
        for name in z.namelist():
            if not name.endswith('.csv'):continue
            for d in pd.read_csv(z.open(name),sep=';',dtype=str,chunksize=100000,usecols=['Estado - Sigla','Municipio','Produto','Valor de Venda']):
                d=d[d.Produto.eq('GASOLINA')];d=d[d.Municipio.map(norm).eq(d['Estado - Sigla'].map(CAPITALS))]
                v=pd.to_numeric(d['Valor de Venda'].str.replace(',','.',regex=False),errors='coerce')
                counts['capital_gasoline_rows']+=len(v);counts['missing_or_non_numeric']+=int(v.isna().sum());counts['nonpositive_or_nonfinite']+=int((v.notna()&((v<=0)|~np.isfinite(v))).sum())
    report.append(counts)
(root/'07_validation/price_validity_flags_only.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
