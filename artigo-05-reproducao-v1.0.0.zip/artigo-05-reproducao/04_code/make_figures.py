"""Deterministic scientific figures from frozen confirmation outputs."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':130,'savefig.dpi':200})
def main():
    r=ROOT/'05_results/confirmation';out=ROOT/'06_manuscript/figures';out.mkdir(exist_ok=True)
    x=pd.read_csv(r/'eligible_contrasts.csv',parse_dates=['week']);p=pd.read_csv(r/'by_capital.csv').sort_values('mean_abs_C')
    fig,ax=plt.subplots(figsize=(7,8));ax.barh(p.uf,p.mean_abs_C*100,color='#275d7e');ax.axvline(2,color='#a44a20',ls='--',lw=1,label='Referência editorial: 2 centavos/L');ax.set(xlabel='Média de |C| (centavos por litro)',ylabel='Capital identificada pela UF');ax.legend(loc='lower right',fontsize=8);fig.tight_layout();fig.savefig(out/'figure_1_capitals.png');fig.savefig(out/'figure_1_capitals.svg');plt.close(fig)
    weeks=pd.date_range('2024-01-07','2025-12-21',freq='7D');m=x.pivot(index='uf',columns='week',values='C').reindex(index=sorted(p.uf),columns=weeks)*100
    fig,ax=plt.subplots(figsize=(9,6));cm=plt.get_cmap('RdBu_r').copy();cm.set_bad('#dedede');limit=float(np.nanmax(np.abs(m)))
    im=ax.imshow(m,aspect='auto',cmap=cm,vmin=-limit,vmax=limit,interpolation='nearest');ax.set_yticks(range(27),m.index);ticks=[0,13,26,39,52,65,78,91,102];ax.set_xticks(ticks,[weeks[i].strftime('%d/%m/%y') for i in ticks],rotation=40,ha='right');ax.set_xlabel('Semana atual da transição');fig.colorbar(im,ax=ax,label='C = D − W (centavos/L)');fig.tight_layout();fig.savefig(out/'figure_2_weekly.png');plt.close(fig)
    v=x.sort_values('absC');fig,ax=plt.subplots(figsize=(7,4));ax.step(v.absC*100,v.weight.cumsum(),where='post',color='#275d7e');ax.axvline(2,color='#a44a20',ls='--',lw=1);ax.set(xlabel='Discrepância absoluta (centavos/L)',ylabel='Frequência acumulada ponderada',ylim=(0,1.01));ax.grid(alpha=.2);fig.tight_layout();fig.savefig(out/'figure_3_distribution.png');plt.close(fig)
    cov=pd.read_csv(r/'coverage_all_expected.csv',parse_dates=['week']);wk=cov.groupby('week').agg(eligible=('eligible',lambda q:q.fillna(False).sum()),common=('n_common','sum'),current=('n_now','sum'))
    fig,ax=plt.subplots(figsize=(8,3.8));ax.plot(wk.index,wk.eligible,color='#275d7e');ax.set(ylabel='Capitais com ≥5 cadastros comuns',xlabel='Semana atual',ylim=(0,28));ax.grid(alpha=.2);fig.autofmt_xdate();fig.tight_layout();fig.savefig(out/'figure_4_coverage.png');plt.close(fig)
    manifest={p.name:p.stat().st_size for p in out.glob('*.png')};(out/'figure_manifest.json').write_text(json.dumps(manifest,indent=2));print(manifest)
if __name__=='__main__':main()
