# Proveniência do estudo e desta edição

## Identificação

- Artigo 5: **Variações semanais da gasolina comum nas capitais brasileiras: comparação entre amostras sucessivas e cadastros comuns**.
- Estudo descritivo dos microdados da ANP. Desenvolvimento em 2023; confirmação de 7/1/2024 a 21/12/2025, com semana-base compartilhada de 31/12/2023.
- Congelamento local: decisão A5-D02, em 6/9/2026. Não houve pré-registro externo.
- Entrega aprovada internamente pela orquestração por IA: A5-D03, em 6/9/2026. Isso não é aceite de periódico, revisão humana ou certificação institucional.

## Papéis declarados

| Papel neutro | Produto/ambiente documentado | Função e alcance |
|---|---|---|
| IA-O — orquestração | ChatGPT em modo Pro, conversa canônica | Escolha da pergunta, decisões teórico-metodológicas, critérios de viabilidade, congelamento e avaliação final. |
| IA-E — execução | Codex, ambiente local Linux/Python | Pesquisa de fontes, aquisição, programação, análise, testes, figuras, manuscrito e montagem dos artefatos. |
| IA-R — revisão | ChatGPT em modo Pro, conversa temporária iniciada sem o histórico de elaboração | Crítica do protocolo, depois do manuscrito e das correções; a conversa de revisão foi mantida entre as rodadas. |
| Participação humana | Solicitação e infraestrutura operacional, conforme declaração do projeto | Sem atribuição de supervisão, revisão ou aprovação científica humana que não tenha sido documentada. |

Os registros consultados identificam produtos e funções. Esta ficha não infere a versão exata do modelo de backend a partir de um nome comercial ou de um rótulo de interface. Esse campo fica explicitamente não estabelecido quando falta um registro suficiente por etapa.

## O que a verificação permite afirmar

1. Há código de recálculo independente a partir dos ZIPs brutos, sem usar as funções de agregação principais para reconstruir os contrastes. Há importações compartilhadas de definições, como as capitais; isso não constitui independência total do projeto.
2. Há reprodução em ambiente novo, com comparação de saídas. Trata-se de nova execução computacional, não de validação externa por pessoa que não participou do trabalho.
3. A decisão final da orquestração relata recálculos próprios a partir dos CSVs de contrastes e níveis municipais. Ela declara que não refez, naquela conversa, a extração completa dos oito arquivos brutos. Esta distinção foi preservada.
4. Não há, nesta entrega, evidência de reprodução por pesquisadores humanos externos, revisão por pares ou comparação controlada entre modelos de IA.

## Correções e limitações preservadas

- Um verificador inicialmente divergiu em fronteiras numéricas ao comparar valores Decimal com limiares float. A correção usou limiares Decimal exatos no verificador; não alterou o estimando principal.
- A entrada principal foi alinhada ao protocolo para remover somente duplicatas inteiramente idênticas e rejeitar conflitos. Os dados reais tinham zero duplicatas exatas nessa verificação.
- A margem editorial de dois centavos não é teste de equivalência. Discordância de classes e oposição entre aumento e queda são resultados distintos.
- Os cadastros comuns não representam automaticamente um comparador superior. Seleção, calendário, cobertura e interpretação retrospectiva permanecem limitações.

## Documentos de origem

Esta ficha sintetiza o README científico, o protocolo congelado, o registro de emendas e a decisão final A5-D03. Identificações SHA-256 desses registros estão em `proveniencia.json`; as conversas integrais e os registros de interface permanecem no acervo privado. Seus hashes permitem identificar as versões consultadas, mas não tornam públicos documentos que não estão neste pacote nem certificam a verdade de seu conteúdo.

Referências históricas a `00_governance/` no suplemento ou em `freeze.json` remetem a esse acervo privado. A execução científica desta edição não depende desses arquivos. Não foram publicadas conversas brutas para sustentar uma alegação de autonomia.

## Preparação desta edição

Preparação computacional por Codex em 11/9/2026. Os dados congelados, o protocolo, o PDF e o código científico selecionado foram preservados byte a byte. Foram criados um executor portátil dentro do ambiente suportado, documentação de uso, manifesto, ficha de proveniência e formulário local de relato. A cópia do suplemento substitui caminhos absolutos por relativos e declara essa edição. Não houve nova escolha de método ou alteração de resultado científico.
